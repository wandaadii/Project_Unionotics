-- Upgrade permission modul karyawan V3.
-- Tidak mengubah isi data pada tb_employees.
-- Untuk pemeriksaan kolom dan penambahan index secara aman,
-- gunakan perintah: npm run db:upgrade

INSERT IGNORE INTO role_permissions
  (role, resource, action, allowed)
VALUES
  ('sub_admin', 'dashboard', 'read', 1),
  ('sub_admin', 'employees', 'read', 1),
  ('sub_admin', 'employees', 'create', 1),
  ('sub_admin', 'employees', 'update', 1),
  ('sub_admin', 'employees', 'delete', 1),
  ('sub_admin', 'users', 'read', 1),
  ('sub_admin', 'users', 'create', 1),
  ('sub_admin', 'users', 'update', 1),
  ('sub_admin', 'users', 'delete', 1),
  ('user', 'dashboard', 'read', 1),
  ('user', 'employees', 'read', 1),
  ('user', 'employees', 'create', 0),
  ('user', 'employees', 'update', 0),
  ('user', 'employees', 'delete', 0),
  ('user', 'users', 'read', 0),
  ('user', 'users', 'create', 0),
  ('user', 'users', 'update', 0),
  ('user', 'users', 'delete', 0);

-- Upgrade permission modul karyawan tanpa mengubah data tb_employees.
-- Jalankan pada database yang sama dengan tabel users, role_permissions,
-- dan tb_employees.

INSERT INTO role_permissions (role, resource, action, allowed)
VALUES
  ('sub_admin', 'employees', 'read', 1),
  ('sub_admin', 'employees', 'create', 1),
  ('sub_admin', 'employees', 'update', 1),
  ('sub_admin', 'employees', 'delete', 1),
  ('user', 'employees', 'read', 1),
  ('user', 'employees', 'create', 0),
  ('user', 'employees', 'update', 0),
  ('user', 'employees', 'delete', 0)
ON DUPLICATE KEY UPDATE role = VALUES(role);

-- Index dapat ditambahkan melalui:
-- npm run db:upgrade
-- Skrip Node akan memeriksa index yang sudah ada sebelum menambahkannya.

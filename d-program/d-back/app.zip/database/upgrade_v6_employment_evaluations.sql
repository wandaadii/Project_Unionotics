-- Jalankan pada database aplikasi setelah melakukan backup.
-- Skrip ini tidak menghapus data tb_employees.

ALTER TABLE tb_employees
  MODIFY employment_status ENUM(
    'Tetap','Kontrak','Magang','PKL','Resign'
  ) NULL DEFAULT 'Kontrak';

CREATE TABLE IF NOT EXISTS employee_evaluations (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  employee_id INT NOT NULL,
  evaluation_number INT NOT NULL,
  evaluation_type ENUM('Tahunan','Akhir Masa') NOT NULL,
  evaluation_date DATE NOT NULL,
  period_end_date DATE NOT NULL,
  policy_label VARCHAR(150) NOT NULL,
  education_group VARCHAR(30) NULL DEFAULT NULL,
  decision ENUM(
    'Pending','Dilanjutkan','Tidak Dilanjutkan'
  ) NOT NULL DEFAULT 'Pending',
  decision_notes TEXT NULL DEFAULT NULL,
  decided_by BIGINT UNSIGNED NULL DEFAULT NULL,
  decided_at TIMESTAMP NULL DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_employee_evaluation_period (
    employee_id, evaluation_number, period_end_date
  ),
  KEY idx_evaluation_pending_end (decision, period_end_date),
  KEY idx_evaluation_employee_end (employee_id, period_end_date),
  KEY idx_evaluation_decided_by (decided_by),
  CONSTRAINT fk_evaluation_employee
    FOREIGN KEY (employee_id) REFERENCES tb_employees(id)
    ON DELETE CASCADE,
  CONSTRAINT fk_evaluation_user
    FOREIGN KEY (decided_by) REFERENCES users(id)
    ON DELETE SET NULL
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO role_permissions
  (role, resource, action, allowed)
VALUES
  ('sub_admin', 'evaluations', 'read', 1),
  ('sub_admin', 'evaluations', 'update', 1),
  ('user', 'evaluations', 'read', 0),
  ('user', 'evaluations', 'update', 0);

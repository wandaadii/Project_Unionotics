CREATE DATABASE IF NOT EXISTS rbac_app
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE rbac_app;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin', 'sub_admin', 'user') NOT NULL DEFAULT 'user',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_role (role),
  KEY idx_users_active (is_active)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS role_permissions (
  role ENUM('sub_admin', 'user') NOT NULL,
  resource VARCHAR(80) NOT NULL,
  action VARCHAR(40) NOT NULL,
  allowed TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (role, resource, action),
  KEY idx_permission_allowed (allowed)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tb_employees (
  id INT NOT NULL AUTO_INCREMENT,
  photo VARCHAR(255) NULL DEFAULT NULL,
  national_id_number VARCHAR(20) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  place_of_birth VARCHAR(50) NULL DEFAULT NULL,
  date_of_birth DATE NULL DEFAULT NULL,
  gender ENUM('Laki-laki','Perempuan') NULL DEFAULT NULL,
  blood_type ENUM('A','B','AB','O') NULL DEFAULT NULL,
  religion VARCHAR(20) NULL DEFAULT NULL,
  marital_status ENUM(
    'Belum Kawin','Kawin','Cerai Hidup','Cerai Mati'
  ) NULL DEFAULT NULL,
  number_of_children INT NULL DEFAULT 0,
  id_card_address TEXT NULL DEFAULT NULL,
  domicile_address TEXT NULL DEFAULT NULL,
  phone_number VARCHAR(15) NULL DEFAULT NULL,
  email VARCHAR(100) NULL DEFAULT NULL,
  emergency_contact VARCHAR(15) NULL DEFAULT NULL,
  last_education VARCHAR(50) NULL DEFAULT NULL,
  educational_institution VARCHAR(100) NULL DEFAULT NULL,
  graduation_year YEAR NULL DEFAULT NULL,
  major VARCHAR(50) NULL DEFAULT NULL,
  employee_id_number VARCHAR(30) NULL DEFAULT NULL,
  plant VARCHAR(20) NULL DEFAULT NULL,
  section VARCHAR(20) NULL DEFAULT NULL,
  line VARCHAR(20) NULL DEFAULT NULL,
  line_status VARCHAR(20) NULL DEFAULT NULL,
  position VARCHAR(50) NULL DEFAULT NULL,
  department VARCHAR(50) NULL DEFAULT NULL,
  date_of_entry DATE NULL DEFAULT NULL,
  employment_status ENUM(
    'Tetap','Kontrak','Magang','PKL','Resign'
  ) NULL DEFAULT 'Kontrak',
  base_salary DECIMAL(10,2) NULL DEFAULT NULL,
  allowance DECIMAL(10,2) NULL DEFAULT 0.00,
  account_number VARCHAR(30) NULL DEFAULT NULL,
  bank VARCHAR(30) NULL DEFAULT NULL,
  bpjs_health VARCHAR(20) NULL DEFAULT NULL,
  bpjs_employment VARCHAR(20) NULL DEFAULT NULL,
  medical_history TEXT NULL DEFAULT NULL,
  other_notes TEXT NULL DEFAULT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_national_id_number (national_id_number),
  INDEX idx_full_name (full_name),
  INDEX idx_employee_id_number (employee_id_number),
  INDEX idx_position (position),
  INDEX idx_employment_status (employment_status),
  INDEX idx_employee_plant (plant),
  INDEX idx_employee_section (section),
  INDEX idx_employee_line (line),
  INDEX idx_employee_line_status (line_status),
  INDEX idx_employee_department (department),
  INDEX idx_employee_entry (date_of_entry),
  INDEX idx_employee_birth (date_of_birth),
  INDEX idx_employee_education (last_education),
  INDEX idx_employee_filter (plant, section, line, employment_status)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS employee_evaluations (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  employee_id INT NOT NULL,
  evaluation_number INT NOT NULL,
  evaluation_type ENUM('Tahunan','Akhir Masa') NOT NULL,
  evaluation_date DATE NOT NULL,
  period_end_date DATE NOT NULL,
  policy_label VARCHAR(150) NOT NULL,
  education_group VARCHAR(30) NULL DEFAULT NULL,
  decision ENUM(
    'Pending','Dilanjutkan','Tidak Dilanjutkan'
  ) NOT NULL DEFAULT 'Pending',
  decision_notes TEXT NULL DEFAULT NULL,
  decided_by BIGINT UNSIGNED NULL DEFAULT NULL,
  decided_at TIMESTAMP NULL DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_employee_evaluation_period (
    employee_id, evaluation_number, period_end_date
  ),
  KEY idx_evaluation_pending_end (decision, period_end_date),
  KEY idx_evaluation_employee_end (employee_id, period_end_date),
  KEY idx_evaluation_decided_by (decided_by),
  CONSTRAINT fk_evaluation_employee
    FOREIGN KEY (employee_id) REFERENCES tb_employees(id)
    ON DELETE CASCADE,
  CONSTRAINT fk_evaluation_user
    FOREIGN KEY (decided_by) REFERENCES users(id)
    ON DELETE SET NULL
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

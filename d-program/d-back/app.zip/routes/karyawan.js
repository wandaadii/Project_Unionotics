const express = require('express');
const router = express.Router();
const db = require('../db');

// =========================================================
// HELPER
// =========================================================

// Ubah string kosong menjadi null
const toNullable = (value) => {
    if (
        value === '' ||
        value === undefined ||
        value === null
    ) {
        return null;
    }

    return value;
};

// Number
const toNullableNumber = (value) => {
    if (
        value === '' ||
        value === undefined ||
        value === null
    ) {
        return null;
    }

    const number = Number(value);

    return Number.isNaN(number)
        ? null
        : number;
};

// Normalisasi tanggal menjadi YYYY-MM-DD
const normalizeDate = (value) => {
    if (
        value === '' ||
        value === undefined ||
        value === null
    ) {
        return null;
    }

    if (value instanceof Date) {
        const year =
            value.getFullYear();

        const month =
            String(
                value.getMonth() + 1
            ).padStart(2, '0');

        const day =
            String(
                value.getDate()
            ).padStart(2, '0');

        return `${year}-${month}-${day}`;
    }

    const stringValue =
        String(value).trim();

    // YYYY-MM-DD
    if (
        /^\d{4}-\d{2}-\d{2}$/.test(
            stringValue
        )
    ) {
        return stringValue;
    }

    // ISO datetime
    if (
        /^\d{4}-\d{2}-\d{2}T/.test(
            stringValue
        )
    ) {
        return stringValue.substring(
            0,
            10
        );
    }

    const parsed =
        new Date(stringValue);

    if (
        Number.isNaN(
            parsed.getTime()
        )
    ) {
        return null;
    }

    const year =
        parsed.getFullYear();

    const month =
        String(
            parsed.getMonth() + 1
        ).padStart(2, '0');

    const day =
        String(
            parsed.getDate()
        ).padStart(2, '0');

    return `${year}-${month}-${day}`;
};

// =========================================================
// GET SEMUA KARYAWAN
// =========================================================

router.get('/', (req, res) => {

    const query = `
        SELECT *
        FROM karyawan

        ORDER BY
            COALESCE(division, ''),
            COALESCE(sub_division, ''),
            COALESCE(department, ''),
            COALESCE(sub_department, ''),
            COALESCE(section, ''),
            COALESCE(sub_section, ''),
            COALESCE(line, ''),
            COALESCE(sub_line, ''),
            COALESCE(name, ''),
            id DESC
    `;

    db.query(
        query,
        (err, results) => {

            if (err) {

                console.error(
                    '❌ Error GET karyawan:',
                    err
                );

                return res.status(500).json({
                    error:
                        'Gagal mengambil data karyawan',
                    detail:
                        err.message
                });
            }

            res.json(results);
        }
    );
});

// =========================================================
// GET KARYAWAN BY ID
// =========================================================

router.get('/:id', (req, res) => {

    const { id } =
        req.params;

    const query = `
        SELECT *
        FROM karyawan
        WHERE id = ?
        LIMIT 1
    `;

    db.query(
        query,
        [id],
        (err, results) => {

            if (err) {

                console.error(
                    '❌ Error GET karyawan by ID:',
                    err
                );

                return res.status(500).json({
                    error:
                        'Gagal mengambil data karyawan',
                    detail:
                        err.message
                });
            }

            if (
                results.length === 0
            ) {

                return res.status(404).json({
                    error:
                        'Karyawan tidak ditemukan'
                });
            }

            res.json(
                results[0]
            );
        }
    );
});

// =========================================================
// CREATE KARYAWAN
// =========================================================

router.post('/', (req, res) => {

    const data =
        req.body || {};

    // -----------------------------------------------------
    // VALIDASI REQUIRED
    // -----------------------------------------------------

    if (
        !data.national_id ||
        String(
            data.national_id
        ).trim() === ''
    ) {
        return res.status(400).json({
            error: 'NIK wajib diisi'
        });
    }

    if (
        !data.name ||
        String(
            data.name
        ).trim() === ''
    ) {
        return res.status(400).json({
            error: 'Nama wajib diisi'
        });
    }

    // -----------------------------------------------------
    // COLUMNS
    // -----------------------------------------------------

    const columns = [

        'photo',
        'national_id',
        'name',
        'place_of_birth',
        'date_of_birth',

        'gender',
        'blood_type',
        'religion',
        'marital_status',
        'number_of_children',

        'ktp_address',
        'residential_address',
        'phone_number',
        'email',
        'emergency_contact',

        'last_education',
        'educational_institution',
        'graduation_year',
        'major',

        'employee_number',

        'plant',

        'division',
        'sub_division',

        'department',
        'sub_department',

        'section',
        'sub_section',

        'line',
        'sub_line',

        'line_status',
        'position',

        'join_date',
        'employment_status',

        'basic_salary',
        'allowance',

        'bank_account_number',
        'bank_name',

        'health_insurance_number',
        'employment_insurance_number',

        'medical_history',
        'other_notes'
    ];

    // -----------------------------------------------------
    // VALUES
    // -----------------------------------------------------

    const values = [

        toNullable(data.photo),
        toNullable(data.national_id),
        toNullable(data.name),
        toNullable(data.place_of_birth),
        normalizeDate(
            data.date_of_birth
        ),

        toNullable(data.gender),
        toNullable(data.blood_type),
        toNullable(data.religion),
        toNullable(data.marital_status),
        toNullableNumber(
            data.number_of_children
        ),

        toNullable(
            data.ktp_address
        ),
        toNullable(
            data.residential_address
        ),
        toNullable(
            data.phone_number
        ),
        toNullable(
            data.email
        ),
        toNullable(
            data.emergency_contact
        ),

        toNullable(
            data.last_education
        ),
        toNullable(
            data.educational_institution
        ),
        toNullableNumber(
            data.graduation_year
        ),
        toNullable(
            data.major
        ),

        toNullable(
            data.employee_number
        ),

        toNullable(
            data.plant
        ),

        // ORGANISASI

        toNullable(
            data.division
        ),
        toNullable(
            data.sub_division
        ),

        toNullable(
            data.department
        ),
        toNullable(
            data.sub_department
        ),

        toNullable(
            data.section
        ),
        toNullable(
            data.sub_section
        ),

        toNullable(
            data.line
        ),
        toNullable(
            data.sub_line
        ),

        toNullable(
            data.line_status
        ),
        toNullable(
            data.position
        ),

        normalizeDate(
            data.join_date
        ),

        toNullable(
            data.employment_status
        ) || 'Kontrak',

        toNullableNumber(
            data.basic_salary
        ),
        toNullableNumber(
            data.allowance
        ),

        toNullable(
            data.bank_account_number
        ),
        toNullable(
            data.bank_name
        ),

        toNullable(
            data.health_insurance_number
        ),
        toNullable(
            data.employment_insurance_number
        ),

        toNullable(
            data.medical_history
        ),
        toNullable(
            data.other_notes
        )
    ];

    // -----------------------------------------------------
    // PLACEHOLDERS
    // -----------------------------------------------------

    const placeholders =
        columns
            .map(() => '?')
            .join(', ');

    // -----------------------------------------------------
    // QUERY
    // -----------------------------------------------------

    const query = `
        INSERT INTO karyawan (
            ${columns.join(', ')}
        )
        VALUES (
            ${placeholders}
        )
    `;

    console.log(
        '📤 INSERT Karyawan:',
        data
    );

    db.query(
        query,
        values,
        (err, result) => {

            if (err) {

                console.error(
                    '❌ Error INSERT karyawan:',
                    err
                );

                return res.status(500).json({
                    error:
                        'Gagal menambahkan karyawan',
                    detail:
                        err.message
                });
            }

            res.status(201).json({

                message:
                    'Data karyawan berhasil ditambahkan',

                id:
                    result.insertId
            });
        }
    );
});

// =========================================================
// UPDATE KARYAWAN
// =========================================================

router.put('/:id', (req, res) => {

    const { id } =
        req.params;

    const data =
        req.body || {};

    // -----------------------------------------------------
    // VALIDASI
    // -----------------------------------------------------

    if (
        !data.national_id ||
        String(
            data.national_id
        ).trim() === ''
    ) {
        return res.status(400).json({
            error: 'NIK wajib diisi'
        });
    }

    if (
        !data.name ||
        String(
            data.name
        ).trim() === ''
    ) {
        return res.status(400).json({
            error: 'Nama wajib diisi'
        });
    }

    // -----------------------------------------------------
    // COLUMNS
    // -----------------------------------------------------

    const columns = [

        'photo',
        'national_id',
        'name',
        'place_of_birth',
        'date_of_birth',

        'gender',
        'blood_type',
        'religion',
        'marital_status',
        'number_of_children',

        'ktp_address',
        'residential_address',
        'phone_number',
        'email',
        'emergency_contact',

        'last_education',
        'educational_institution',
        'graduation_year',
        'major',

        'employee_number',

        'plant',

        'division',
        'sub_division',

        'department',
        'sub_department',

        'section',
        'sub_section',

        'line',
        'sub_line',

        'line_status',
        'position',

        'join_date',
        'employment_status',

        'basic_salary',
        'allowance',

        'bank_account_number',
        'bank_name',

        'health_insurance_number',
        'employment_insurance_number',

        'medical_history',
        'other_notes'
    ];

    // -----------------------------------------------------
    // SET CLAUSE
    // -----------------------------------------------------

    const setClause =
        columns
            .map(
                (column) =>
                    `${column} = ?`
            )
            .join(', ');

    // -----------------------------------------------------
    // QUERY
    // -----------------------------------------------------

    const query = `
        UPDATE karyawan
        SET ${setClause}
        WHERE id = ?
    `;

    // -----------------------------------------------------
    // VALUES
    // -----------------------------------------------------

    const values = [

        toNullable(data.photo),
        toNullable(
            data.national_id
        ),
        toNullable(data.name),
        toNullable(
            data.place_of_birth
        ),
        normalizeDate(
            data.date_of_birth
        ),

        toNullable(data.gender),
        toNullable(
            data.blood_type
        ),
        toNullable(data.religion),
        toNullable(
            data.marital_status
        ),
        toNullableNumber(
            data.number_of_children
        ),

        toNullable(
            data.ktp_address
        ),
        toNullable(
            data.residential_address
        ),
        toNullable(
            data.phone_number
        ),
        toNullable(data.email),
        toNullable(
            data.emergency_contact
        ),

        toNullable(
            data.last_education
        ),
        toNullable(
            data.educational_institution
        ),
        toNullableNumber(
            data.graduation_year
        ),
        toNullable(data.major),

        toNullable(
            data.employee_number
        ),

        toNullable(data.plant),

        // ORGANISASI

        toNullable(
            data.division
        ),
        toNullable(
            data.sub_division
        ),

        toNullable(
            data.department
        ),
        toNullable(
            data.sub_department
        ),

        toNullable(
            data.section
        ),
        toNullable(
            data.sub_section
        ),

        toNullable(
            data.line
        ),
        toNullable(
            data.sub_line
        ),

        toNullable(
            data.line_status
        ),
        toNullable(
            data.position
        ),

        normalizeDate(
            data.join_date
        ),

        toNullable(
            data.employment_status
        ) || 'Kontrak',

        toNullableNumber(
            data.basic_salary
        ),
        toNullableNumber(
            data.allowance
        ),

        toNullable(
            data.bank_account_number
        ),
        toNullable(
            data.bank_name
        ),

        toNullable(
            data.health_insurance_number
        ),
        toNullable(
            data.employment_insurance_number
        ),

        toNullable(
            data.medical_history
        ),
        toNullable(
            data.other_notes
        ),

        id
    ];

    console.log(
        `📤 UPDATE Karyawan ID ${id}:`,
        data
    );

    // -----------------------------------------------------
    // EXECUTE
    // -----------------------------------------------------

    db.query(
        query,
        values,
        (err, result) => {

            if (err) {

                console.error(
                    '❌ Error UPDATE karyawan:',
                    err
                );

                return res.status(500).json({
                    error:
                        'Gagal memperbarui data karyawan',
                    detail:
                        err.message
                });
            }

            if (
                result.affectedRows === 0
            ) {

                return res.status(404).json({
                    error:
                        'Karyawan tidak ditemukan'
                });
            }

            res.json({

                message:
                    'Data karyawan berhasil diperbarui',

                id
            });
        }
    );
});

// =========================================================
// DELETE KARYAWAN
// =========================================================

router.delete('/:id', (req, res) => {

    const { id } =
        req.params;

    const query = `
        DELETE FROM karyawan
        WHERE id = ?
    `;

    db.query(
        query,
        [id],
        (err, result) => {

            if (err) {

                console.error(
                    '❌ Error DELETE karyawan:',
                    err
                );

                return res.status(500).json({
                    error:
                        'Gagal menghapus karyawan',
                    detail:
                        err.message
                });
            }

            if (
                result.affectedRows === 0
            ) {

                return res.status(404).json({
                    error:
                        'Karyawan tidak ditemukan'
                });
            }

            res.json({
                message:
                    'Data karyawan berhasil dihapus',
                id
            });
        }
    );
});

module.exports = router;
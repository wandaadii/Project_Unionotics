//
// ============================================================
// FILE: src/App.jsx
// ============================================================

import React, { useState } from 'react';

import Navbar from './components/navbar/Navbar';
import Sidebar from './components/sidebar/Sidebar';

import Karyawan from './components/pages/Karyawan';
import Dashboard from './components/pages/Dashboard';

const App = () => {
    const [sidebarCollapsed, setSidebarCollapsed] =
        useState(false);

    const [activeMenu, setActiveMenu] =
        useState('dashboard');

    const [mobileSidebarOpen, setMobileSidebarOpen] =
        useState(false);

    const toggleSidebar = () => {
        setSidebarCollapsed((prev) => !prev);
    };

    const toggleMobileSidebar = () => {
        setMobileSidebarOpen((prev) => !prev);
    };

    const closeMobileSidebar = () => {
        setMobileSidebarOpen(false);
    };

    const handleMenuChange = (menu) => {
        setActiveMenu(menu);
        closeMobileSidebar();
    };

    const renderContent = () => {
        switch (activeMenu) {
            case 'dashboard':
                return <Dashboard />;

            case 'karyawan':
                return <Karyawan />;

            default:
                return (
                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
                        <h1 className="text-2xl font-bold text-slate-800">
                            Dalam proses pengerjaan
                        </h1>

                        <p className="mt-2 text-sm text-slate-500">
                            Menu ini masih dalam tahap
                            pengembangan.
                        </p>
                    </div>
                );
        }
    };

    return (
        <div className="min-h-screen bg-gray-50">

            {/* =================================================
                SIDEBAR
            ================================================= */}

            <Sidebar
                collapsed={sidebarCollapsed}
                onToggle={toggleSidebar}
                setActiveMenu={handleMenuChange}
                activeMenu={activeMenu}
                isMobileOpen={mobileSidebarOpen}
                onMobileClose={
                    closeMobileSidebar
                }
            />

            {/* =================================================
                MOBILE OVERLAY
            ================================================= */}

            {mobileSidebarOpen && (
                <div
                    className="fixed inset-0 bg-black/50 z-40 md:hidden"
                    onClick={closeMobileSidebar}
                    aria-hidden="true"
                />
            )}

            {/* =================================================
                MAIN AREA
            ================================================= */}

            <div
                className={`min-h-screen transition-all duration-300 ${
                    sidebarCollapsed
                        ? 'md:ml-24'
                        : 'md:ml-64'
                }`}
            >

                {/* NAVBAR */}

                <Navbar
                    onMenuClick={
                        toggleMobileSidebar
                    }
                    activeMenu={activeMenu}
                />

                {/* CONTENT */}

                <main className="p-3 sm:p-4 md:p-6 min-w-0">
                    {renderContent()}
                </main>
            </div>
        </div>
    );
};

export default App;




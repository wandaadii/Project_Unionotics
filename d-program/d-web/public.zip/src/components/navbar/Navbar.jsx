
//
// ============================================================
// FILE: src/components/navbar/Navbar.jsx
// ============================================================

import React from 'react';

import {
    Menu,
    Bell,
    Search
} from 'lucide-react';

const Navbar = ({
    onMenuClick,
    activeMenu
}) => {
    const pageTitleMap = {
        dashboard: 'Dashboard',
        karyawan: 'Karyawan',
        pengumuman: 'Pengumuman',
        pengaturan: 'Pengaturan',
        bantuan: 'Bantuan'
    };

    const pageTitle =
        pageTitleMap[activeMenu] ||
        'SPM Union';

    return (
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 shadow-sm">

            <div className="h-16 px-3 sm:px-4 md:px-6 flex items-center justify-between gap-3">

                {/* LEFT */}

                <div className="flex items-center gap-3 min-w-0">

                    {/* MOBILE MENU */}

                    <button
                        type="button"
                        onClick={onMenuClick}
                        className="md:hidden inline-flex items-center justify-center w-10 h-10 rounded-lg text-slate-600 hover:bg-slate-100"
                        aria-label="Buka menu"
                    >
                        <Menu size={22} />
                    </button>

                    {/* TITLE */}

                    <div className="min-w-0">
                        <h1 className="text-base sm:text-lg font-bold text-slate-800 truncate">
                            {pageTitle}
                        </h1>

                        <p className="hidden sm:block text-xs text-slate-400 truncate">
                            SPM Union Management System
                        </p>
                    </div>

                </div>

                {/* RIGHT */}

                <div className="flex items-center gap-1 sm:gap-2">

                    <button
                        type="button"
                        className="hidden sm:inline-flex items-center justify-center w-10 h-10 rounded-lg text-slate-500 hover:bg-slate-100"
                        title="Pencarian"
                    >
                        <Search size={20} />
                    </button>

                    <button
                        type="button"
                        className="relative inline-flex items-center justify-center w-10 h-10 rounded-lg text-slate-500 hover:bg-slate-100"
                        title="Notifikasi"
                    >
                        <Bell size={20} />

                        <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white" />
                    </button>

                    {/* USER */}

                    <div className="hidden sm:flex items-center gap-2 ml-2 pl-2 border-l border-gray-200">

                        <div className="w-9 h-9 rounded-full bg-cyan-500 text-white flex items-center justify-center font-semibold">
                            A
                        </div>

                        <div className="hidden lg:block">
                            <p className="text-sm font-medium text-slate-700 leading-none">
                                Admin
                            </p>

                            <p className="text-xs text-slate-400 mt-1">
                                Administrator
                            </p>
                        </div>

                    </div>

                </div>

            </div>
        </header>
    );
};

export default Navbar;
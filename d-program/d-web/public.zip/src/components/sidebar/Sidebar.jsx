//
// ============================================================
// FILE: src/components/sidebar/Sidebar.jsx
// ============================================================

import React from 'react';

import {
    LayoutDashboard,
    Users,
    Megaphone,
    Settings,
    HelpCircle,
    ChevronLeft,
    ChevronRight,
    X
} from 'lucide-react';

import logo from '../../assets/spmunion.jpeg';

const Sidebar = ({
    collapsed,
    onToggle,
    setActiveMenu,
    activeMenu,
    isMobileOpen,
    onMobileClose
}) => {
    const menuItems = [
        {
            name: 'Dashboard',
            icon: LayoutDashboard,
            key: 'dashboard'
        },
        {
            name: 'Karyawan',
            icon: Users,
            key: 'karyawan'
        },
        {
            name: 'Pengumuman',
            icon: Megaphone,
            key: 'pengumuman'
        },
        {
            name: 'Pengaturan',
            icon: Settings,
            key: 'pengaturan'
        },
        {
            name: 'Bantuan',
            icon: HelpCircle,
            key: 'bantuan'
        }
    ];

    const baseClasses =
        'bg-gradient-to-b from-slate-800 to-slate-900 text-white h-screen fixed left-0 top-0 z-50 shadow-xl transition-all duration-300 ease-in-out';

    const desktopWidth = collapsed
        ? 'w-24'
        : 'w-64';

    const mobileTransform =
        isMobileOpen
            ? 'translate-x-0'
            : '-translate-x-full';

    const handleMenuClick = (key) => {
        setActiveMenu(key);
    };

    const renderMenu = (isMobile = false) => {
        return (
            <ul className="space-y-1">
                {menuItems.map((item) => {
                    const Icon = item.icon;

                    const active =
                        activeMenu === item.key;

                    return (
                        <li key={item.key}>
                            <button
                                type="button"
                                onClick={() =>
                                    handleMenuClick(
                                        item.key
                                    )
                                }
                                title={
                                    !isMobile &&
                                    collapsed
                                        ? item.name
                                        : undefined
                                }
                                className={`
                                    w-full flex items-center
                                    ${
                                        !isMobile &&
                                        collapsed
                                            ? 'justify-center'
                                            : 'space-x-3'
                                    }
                                    px-4 py-3 rounded-lg
                                    transition-all duration-200
                                    ${
                                        active
                                            ? 'bg-cyan-600 text-white shadow-md'
                                            : 'text-slate-200 hover:bg-slate-700 hover:text-white'
                                    }
                                `}
                            >
                                <Icon
                                    size={22}
                                    className={`flex-shrink-0 ${
                                        active
                                            ? 'text-white'
                                            : 'text-slate-400'
                                    }`}
                                />

                                {(!collapsed ||
                                    isMobile) && (
                                    <span className="text-sm font-medium truncate">
                                        {
                                            item.name
                                        }
                                    </span>
                                )}
                            </button>
                        </li>
                    );
                })}
            </ul>
        );
    };

    return (
        <>
            {/* =================================================
                DESKTOP SIDEBAR
            ================================================= */}

            <aside
                className={`
                    ${baseClasses}
                    hidden md:flex
                    flex-col
                    ${desktopWidth}
                `}
            >

                {/* HEADER */}

                <div
                    className={`
                        flex items-center
                        ${
                            collapsed
                                ? 'justify-center'
                                : 'space-x-3'
                        }
                        px-5 py-6
                        border-b border-slate-700
                    `}
                >
                    <img
                        src={logo}
                        alt="SPM Union Logo"
                        className="w-12 h-12 rounded-lg object-cover shadow-lg flex-shrink-0"
                    />

                    {!collapsed && (
                        <div className="overflow-hidden">
                            <h2 className="text-xl font-bold tracking-tight whitespace-nowrap">
                                SPM Union
                            </h2>

                            <p className="text-xs text-slate-400 whitespace-nowrap">
                                Management System
                            </p>
                        </div>
                    )}
                </div>

                {/* MENU */}

                <nav className="flex-1 p-3 overflow-y-auto">
                    {renderMenu(false)}
                </nav>

                {/* USER */}

                {!collapsed && (
                    <div className="p-4 border-t border-slate-700">
                        <div className="flex items-center space-x-3 px-2 py-2">
                            <div className="w-9 h-9 bg-slate-600 rounded-full flex items-center justify-center flex-shrink-0">
                                <span className="text-white text-sm">
                                    A
                                </span>
                            </div>

                            <div className="flex-1 overflow-hidden">
                                <p className="text-sm font-medium truncate">
                                    Admin
                                </p>

                                <p className="text-xs text-slate-400 truncate">
                                    unionotics@company.com
                                </p>
                            </div>
                        </div>
                    </div>
                )}

                {/* COLLAPSE BUTTON */}

                <button
                    type="button"
                    onClick={onToggle}
                    className="absolute -right-3 top-1/2 -translate-y-1/2 bg-cyan-500 text-white rounded-full p-1.5 shadow-lg hover:bg-cyan-600 transition z-50"
                    title={
                        collapsed
                            ? 'Buka Sidebar'
                            : 'Tutup Sidebar'
                    }
                >
                    {collapsed ? (
                        <ChevronRight
                            size={20}
                        />
                    ) : (
                        <ChevronLeft
                            size={20}
                        />
                    )}
                </button>
            </aside>

            {/* =================================================
                MOBILE SIDEBAR
            ================================================= */}

            <aside
                className={`
                    ${baseClasses}
                    block md:hidden
                    w-72
                    ${mobileTransform}
                `}
            >

                {/* HEADER */}

                <div className="flex items-center justify-between px-5 py-6 border-b border-slate-700">

                    <div className="flex items-center space-x-3 min-w-0">
                        <img
                            src={logo}
                            alt="SPM Union Logo"
                            className="w-12 h-12 rounded-lg object-cover shadow-lg flex-shrink-0"
                        />

                        <div className="min-w-0">
                            <h2 className="text-xl font-bold tracking-tight truncate">
                                SPM Union
                            </h2>

                            <p className="text-xs text-slate-400 truncate">
                                Management System
                            </p>
                        </div>
                    </div>

                    <button
                        type="button"
                        onClick={
                            onMobileClose
                        }
                        className="p-2 rounded-lg text-slate-400 hover:bg-slate-700 hover:text-white flex-shrink-0"
                        aria-label="Tutup menu"
                    >
                        <X size={24} />
                    </button>

                </div>

                {/* MENU */}

                <nav className="p-3 overflow-y-auto h-[calc(100vh-150px)]">
                    {renderMenu(true)}
                </nav>

                {/* USER */}

                <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-slate-700 bg-slate-900/80">

                    <div className="flex items-center space-x-3 px-2 py-2">

                        <div className="w-9 h-9 bg-slate-600 rounded-full flex items-center justify-center flex-shrink-0">
                            <span className="text-white text-sm">
                                A
                            </span>
                        </div>

                        <div className="flex-1 overflow-hidden">
                            <p className="text-sm font-medium truncate">
                                Admin
                            </p>

                            <p className="text-xs text-slate-400 truncate">
                                unionotics@company.com
                            </p>
                        </div>

                    </div>
                </div>
            </aside>
        </>
    );
};

export default Sidebar;

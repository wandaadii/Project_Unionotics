
import React, {
    useEffect,
    useMemo,
    useState
} from 'react';

import {
    Users,
    UserCheck,
    UserX,
    BriefcaseBusiness,
    CalendarDays,
    Building2,
    TrendingUp
} from 'lucide-react';

import {
    ResponsiveContainer,
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    PieChart,
    Pie,
    Cell
} from 'recharts';

const API_URL = '/api/karyawan';

/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/

const normalizeDate = (value) => {
    if (!value) {
        return null;
    }

    if (typeof value === 'string') {
        const trimmed = value.trim();

        if (
            /^\d{4}-\d{2}-\d{2}$/.test(
                trimmed
            )
        ) {
            return trimmed;
        }

        if (
            /^\d{4}-\d{2}-\d{2}T/.test(
                trimmed
            )
        ) {
            return trimmed.substring(
                0,
                10
            );
        }
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return null;
    }

    return date.toISOString().substring(
        0,
        10
    );
};

/*
|--------------------------------------------------------------------------
| KATEGORI POSISI
|--------------------------------------------------------------------------
*/

const getPositionCategory = (
    position
) => {
    const value = String(
        position || ''
    ).trim().toLowerCase();

    if (!value) {
        return 'Lainnya';
    }

    /*
    |--------------------------------------------------------------------------
    | MANAGEMENT
    |--------------------------------------------------------------------------
    */

    if (
        value.includes('director') ||
        value.includes('direktur') ||
        value.includes('advisor') ||
        value.includes('president') ||
        value.includes('general manager') ||
        value === 'manager' ||
        value.includes('manager')
    ) {
        return 'Management';
    }

    /*
    |--------------------------------------------------------------------------
    | SUPERVISOR / LEADER
    |--------------------------------------------------------------------------
    */

    if (
        value.includes('supervisor') ||
        value.includes('superintendent') ||
        value.includes('leader') ||
        value.includes('chief') ||
        value.includes('section head') ||
        value.includes('group leader') ||
        value.includes('foreman')
    ) {
        return 'Supervisor / Leader';
    }

    /*
    |--------------------------------------------------------------------------
    | OPERATOR / PRODUCTION
    |--------------------------------------------------------------------------
    */

    if (
        value.includes('operator') ||
        value.includes('production') ||
        value.includes('machining') ||
        value.includes('assembly') ||
        value.includes('assy') ||
        value.includes('qc operator') ||
        value.includes('line operator')
    ) {
        return 'Operator / Production';
    }

    /*
    |--------------------------------------------------------------------------
    | DRIVER / SUPPORT
    |--------------------------------------------------------------------------
    */

    if (
        value.includes('driver') ||
        value.includes('security') ||
        value.includes('utility') ||
        value.includes('cleaning') ||
        value.includes('helper') ||
        value.includes('support')
    ) {
        return 'Driver / Support';
    }

    /*
    |--------------------------------------------------------------------------
    | STAFF / OFFICE
    |--------------------------------------------------------------------------
    */

    if (
        value.includes('staff') ||
        value.includes('admin') ||
        value.includes('engineer') ||
        value.includes('engineering') ||
        value.includes('accounting') ||
        value.includes('purchasing') ||
        value.includes('hr') ||
        value.includes('human resource') ||
        value.includes('finance') ||
        value.includes('marketing') ||
        value.includes('sales') ||
        value.includes('qa') ||
        value.includes('qc') ||
        value.includes('it') ||
        value.includes('safety') ||
        value.includes('secretary') ||
        value.includes('planner') ||
        value.includes('pcd') ||
        value.includes('qad')
    ) {
        return 'Staff / Office';
    }

    return 'Lainnya';
};

/*
|--------------------------------------------------------------------------
| MASA KERJA
|--------------------------------------------------------------------------
*/

const calculateTenureYears = (
    joinDate
) => {
    const normalized =
        normalizeDate(joinDate);

    if (!normalized) {
        return null;
    }

    const start = new Date(
        `${normalized}T00:00:00`
    );

    const now = new Date();

    if (
        Number.isNaN(
            start.getTime()
        ) ||
        start > now
    ) {
        return null;
    }

    const diffMs =
        now.getTime() -
        start.getTime();

    const diffDays =
        diffMs /
        (1000 * 60 * 60 * 24);

    return diffDays / 365.25;
};

const formatYears = (years) => {
    if (
        years === null ||
        years === undefined ||
        Number.isNaN(years)
    ) {
        return '-';
    }

    if (years < 1) {
        const months =
            Math.round(
                years * 12
            );

        return `${months} bln`;
    }

    return `${years.toFixed(1)} thn`;
};

const formatNumber = (
    value
) => {
    return new Intl.NumberFormat(
        'id-ID'
    ).format(value || 0);
};

/*
|--------------------------------------------------------------------------
| TOOLTIP MASA KERJA
|--------------------------------------------------------------------------
*/

const TenureTooltip = ({
    active,
    payload
}) => {
    if (
        !active ||
        !payload ||
        !payload.length
    ) {
        return null;
    }

    const data =
        payload[0].payload;

    return (
        <div className="bg-white border border-gray-200 rounded-lg shadow-lg px-3 py-2">
            <p className="text-sm font-semibold text-gray-800">
                {data.category}
            </p>

            <p className="text-sm text-cyan-600 mt-1">
                Rata-rata:{' '}
                {formatYears(
                    data.averageTenure
                )}
            </p>

            <p className="text-xs text-gray-500 mt-1">
                {formatNumber(
                    data.total
                )}{' '}
                karyawan
            </p>
        </div>
    );
};

/*
|--------------------------------------------------------------------------
| KOMPONEN
|--------------------------------------------------------------------------
*/

const Dashboard = () => {
    const [
        karyawan,
        setKaryawan
    ] = useState([]);

    const [
        loading,
        setLoading
    ] = useState(true);

    const [
        error,
        setError
    ] = useState('');

    /*
    |--------------------------------------------------------------------------
    | FETCH
    |--------------------------------------------------------------------------
    */

    useEffect(() => {
        const fetchData =
            async () => {
                setLoading(true);
                setError('');

                try {
                    const response =
                        await fetch(
                            API_URL
                        );

                    if (
                        !response.ok
                    ) {
                        throw new Error(
                            `HTTP ${response.status}`
                        );
                    }

                    const data =
                        await response.json();

                    setKaryawan(
                        Array.isArray(
                            data
                        )
                            ? data
                            : []
                    );
                } catch (
                    err
                ) {
                    console.error(
                        '❌ Dashboard:',
                        err
                    );

                    setError(
                        'Gagal mengambil data dashboard'
                    );
                } finally {
                    setLoading(false);
                }
            };

        fetchData();
    }, []);

    /*
    |--------------------------------------------------------------------------
    | STATISTIK
    |--------------------------------------------------------------------------
    */

    const stats = useMemo(() => {
        const total =
            karyawan.length;

        const tetap =
            karyawan.filter(
                (item) =>
                    item.employment_status ===
                    'Tetap'
            ).length;

        const kontrak =
            karyawan.filter(
                (item) =>
                    item.employment_status ===
                    'Kontrak'
            ).length;

        const magang =
            karyawan.filter(
                (item) =>
                    item.employment_status ===
                    'Magang'
            ).length;

        const resign =
            karyawan.filter(
                (item) =>
                    item.employment_status ===
                    'Resign'
            ).length;

        const validTenures =
            karyawan
                .map((item) =>
                    calculateTenureYears(
                        item.join_date
                    )
                )
                .filter(
                    (value) =>
                        value !== null
                );

        const averageTenure =
            validTenures.length
                ? validTenures.reduce(
                      (
                          sum,
                          value
                      ) =>
                          sum + value,
                      0
                  ) /
                  validTenures.length
                : 0;

        return {
            total,
            tetap,
            kontrak,
            magang,
            resign,
            averageTenure
        };
    }, [karyawan]);

    /*
    |--------------------------------------------------------------------------
    | STATUS CHART
    |--------------------------------------------------------------------------
    */

    const statusData = useMemo(
        () => [
            {
                name: 'Tetap',
                value: stats.tetap
            },
            {
                name: 'Kontrak',
                value: stats.kontrak
            },
            {
                name: 'Magang',
                value: stats.magang
            },
            {
                name: 'Resign',
                value: stats.resign
            }
        ],
        [stats]
    );

    const statusColors = [
        '#10b981',
        '#f59e0b',
        '#3b82f6',
        '#ef4444'
    ];

    /*
    |--------------------------------------------------------------------------
    | RATA-RATA MASA KERJA PER POSISI
    |--------------------------------------------------------------------------
    */

    const tenureByCategory =
        useMemo(() => {
            const categoryMap =
                {};

            karyawan.forEach(
                (item) => {
                    const category =
                        getPositionCategory(
                            item.position
                        );

                    const tenure =
                        calculateTenureYears(
                            item.join_date
                        );

                    if (
                        !categoryMap[
                            category
                        ]
                    ) {
                        categoryMap[
                            category
                        ] = {
                            category,
                            total: 0,
                            totalTenure: 0,
                            validTenureCount: 0
                        };
                    }

                    categoryMap[
                        category
                    ].total += 1;

                    if (
                        tenure !==
                        null
                    ) {
                        categoryMap[
                            category
                        ].totalTenure +=
                            tenure;

                        categoryMap[
                            category
                        ].validTenureCount +=
                            1;
                    }
                }
            );

            const order = [
                'Management',
                'Supervisor / Leader',
                'Staff / Office',
                'Operator / Production',
                'Driver / Support',
                'Lainnya'
            ];

            return order
                .map(
                    (
                        category
                    ) =>
                        categoryMap[
                            category
                        ]
                )
                .filter(Boolean)
                .map(
                    (item) => ({
                        ...item,
                        averageTenure:
                            item.validTenureCount >
                            0
                                ? item.totalTenure /
                                  item.validTenureCount
                                : 0
                    })
                );
        }, [karyawan]);

    /*
    |--------------------------------------------------------------------------
    | DEPARTMENT
    |--------------------------------------------------------------------------
    */

    const departmentData =
        useMemo(() => {
            const map = {};

            karyawan.forEach(
                (item) => {
                    const name =
                        item.department ||
                        'Belum Diisi';

                    map[name] =
                        (map[name] ||
                            0) + 1;
                }
            );

            return Object.entries(
                map
            )
                .map(
                    ([
                        name,
                        value
                    ]) => ({
                        name,
                        value
                    })
                )
                .sort(
                    (a, b) =>
                        b.value -
                        a.value
                )
                .slice(0, 8);
        }, [karyawan]);

    /*
    |--------------------------------------------------------------------------
    | KARYAWAN TERBARU
    |--------------------------------------------------------------------------
    */

    const recentEmployees =
        useMemo(() => {
            return [
                ...karyawan
            ]
                .sort((a, b) => {
                    const dateA =
                        new Date(
                            a.updated_at ||
                                a.created_at ||
                                a.join_date ||
                                0
                        );

                    const dateB =
                        new Date(
                            b.updated_at ||
                                b.created_at ||
                                b.join_date ||
                                0
                        );

                    return (
                        dateB.getTime() -
                        dateA.getTime()
                    );
                })
                .slice(0, 8);
        }, [karyawan]);

    /*
    |--------------------------------------------------------------------------
    | LOADING
    |--------------------------------------------------------------------------
    */

    if (loading) {
        return (
            <div className="space-y-5">

                <div>
                    <div className="h-7 w-40 bg-gray-200 animate-pulse rounded" />
                    <div className="h-4 w-64 bg-gray-200 animate-pulse rounded mt-2" />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
                    {[1, 2, 3, 4].map(
                        (item) => (
                            <div
                                key={item}
                                className="h-28 bg-white border border-gray-200 rounded-xl animate-pulse"
                            />
                        )
                    )}
                </div>

                <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
                    <div className="h-80 bg-white border border-gray-200 rounded-xl animate-pulse" />
                    <div className="h-80 bg-white border border-gray-200 rounded-xl animate-pulse" />
                </div>

            </div>
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ERROR
    |--------------------------------------------------------------------------
    */

    if (error) {
        return (
            <div className="bg-white border border-red-200 rounded-xl p-6">
                <h2 className="font-semibold text-red-600">
                    Dashboard Error
                </h2>

                <p className="text-sm text-gray-600 mt-2">
                    {error}
                </p>

                <button
                    type="button"
                    onClick={() =>
                        window.location.reload()
                    }
                    className="mt-4 px-4 py-2 text-sm bg-cyan-500 text-white rounded-lg hover:bg-cyan-600"
                >
                    Refresh
                </button>
            </div>
        );
    }

    /*
    |--------------------------------------------------------------------------
    | RENDER
    |--------------------------------------------------------------------------
    */

    return (
        <div className="space-y-5">

            {/* =================================================
                HEADER
            ================================================= */}

            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">

                <div>
                    <h1 className="text-xl sm:text-2xl font-bold text-slate-800">
                        Dashboard
                    </h1>

                    <p className="text-sm text-slate-500 mt-1">
                        Ringkasan data karyawan SPM Union OTICS.
                    </p>
                </div>

                <div className="flex items-center gap-2 text-xs sm:text-sm text-gray-500">
                    <CalendarDays
                        size={16}
                    />

                    <span>
                        Update:{' '}
                        {new Date().toLocaleDateString(
                            'id-ID',
                            {
                                day: '2-digit',
                                month: 'long',
                                year: 'numeric'
                            }
                        )}
                    </span>
                </div>

            </div>

            {/* =================================================
                KPI
            ================================================= */}

            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">

                <StatCard
                    title="Total Karyawan"
                    value={formatNumber(
                        stats.total
                    )}
                    subtitle="Seluruh data karyawan"
                    icon={
                        <Users size={21} />
                    }
                    iconClass="bg-cyan-100 text-cyan-600"
                />

                <StatCard
                    title="Karyawan Tetap"
                    value={formatNumber(
                        stats.tetap
                    )}
                    subtitle={`${stats.total ? (
                        (
                            (stats.tetap /
                                stats.total) *
                            100
                        ).toFixed(1)
                    ) : 0}% dari total`}
                    icon={
                        <UserCheck size={21} />
                    }
                    iconClass="bg-green-100 text-green-600"
                />

                <StatCard
                    title="Karyawan Kontrak"
                    value={formatNumber(
                        stats.kontrak
                    )}
                    subtitle={`${stats.total ? (
                        (
                            (stats.kontrak /
                                stats.total) *
                            100
                        ).toFixed(1)
                    ) : 0}% dari total`}
                    icon={
                        <BriefcaseBusiness
                            size={21}
                        />
                    }
                    iconClass="bg-yellow-100 text-yellow-600"
                />

                <StatCard
                    title="Resign"
                    value={formatNumber(
                        stats.resign
                    )}
                    subtitle={`Magang: ${formatNumber(
                        stats.magang
                    )}`}
                    icon={
                        <UserX size={21} />
                    }
                    iconClass="bg-red-100 text-red-600"
                />

            </div>

            {/* =================================================
                CHART ROW
            ================================================= */}

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">

                {/* STATUS */}

                <DashboardCard
                    title="Status Karyawan"
                    subtitle="Komposisi status employment"
                >

                    <div className="h-[300px]">

                        {stats.total ===
                        0 ? (
                            <EmptyState />
                        ) : (
                            <ResponsiveContainer
                                width="100%"
                                height="100%"
                            >
                                <PieChart>

                                    <Pie
                                        data={
                                            statusData
                                        }
                                        dataKey="value"
                                        nameKey="name"
                                        cx="50%"
                                        cy="50%"
                                        innerRadius={
                                            70
                                        }
                                        outerRadius={
                                            105
                                        }
                                        paddingAngle={
                                            3
                                        }
                                    >
                                        {statusData.map(
                                            (
                                                entry,
                                                index
                                            ) => (
                                                <Cell
                                                    key={
                                                        entry.name
                                                    }
                                                    fill={
                                                        statusColors[
                                                            index %
                                                                statusColors.length
                                                        ]
                                                    }
                                                />
                                            )
                                        )}
                                    </Pie>

                                    <Tooltip
                                        formatter={(
                                            value,
                                            name
                                        ) => [
                                            `${formatNumber(
                                                value
                                            )} karyawan`,
                                            name
                                        ]}
                                    />

                                </PieChart>
                            </ResponsiveContainer>
                        )}

                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">

                        {statusData.map(
                            (item, index) => (
                                <div
                                    key={
                                        item.name
                                    }
                                    className="rounded-lg bg-gray-50 p-2.5"
                                >
                                    <div className="flex items-center gap-1.5">

                                        <span
                                            className="w-2.5 h-2.5 rounded-full"
                                            style={{
                                                backgroundColor:
                                                    statusColors[
                                                        index
                                                    ]
                                            }}
                                        />

                                        <span className="text-xs text-gray-500">
                                            {
                                                item.name
                                            }
                                        </span>

                                    </div>

                                    <p className="font-semibold text-gray-800 mt-1">
                                        {
                                            formatNumber(
                                                item.value
                                            )
                                        }
                                    </p>
                                </div>
                            )
                        )}

                    </div>

                </DashboardCard>

                {/* MASA KERJA */}

                <DashboardCard
                    title="Rata-rata Masa Kerja"
                    subtitle="Dikelompokkan berdasarkan kategori posisi"
                    action={
                        <div className="flex items-center gap-1 text-xs text-cyan-600">
                            <TrendingUp
                                size={14}
                            />
                            <span>
                                Tahun
                            </span>
                        </div>
                    }
                >

                    <div className="h-[360px]">

                        {tenureByCategory.length ===
                        0 ? (
                            <EmptyState />
                        ) : (
                            <ResponsiveContainer
                                width="100%"
                                height="100%"
                            >
                                <BarChart
                                    data={
                                        tenureByCategory
                                    }
                                    layout="vertical"
                                    margin={{
                                        top: 10,
                                        right: 20,
                                        left: 15,
                                        bottom: 10
                                    }}
                                >

                                    <CartesianGrid
                                        strokeDasharray="3 3"
                                        horizontal={false}
                                    />

                                    <XAxis
                                        type="number"
                                        tickFormatter={(
                                            value
                                        ) =>
                                            `${value} thn`
                                        }
                                    />

                                    <YAxis
                                        type="category"
                                        dataKey="category"
                                        width={125}
                                        tick={{
                                            fontSize: 11
                                        }}
                                    />

                                    <Tooltip
                                        content={
                                            <TenureTooltip />
                                        }
                                    />

                                    <Bar
                                        dataKey="averageTenure"
                                        radius={[
                                            0,
                                            5,
                                            5,
                                            0
                                        ]}
                                        fill="#06b6d4"
                                    />

                                </BarChart>
                            </ResponsiveContainer>
                        )}

                    </div>

                </DashboardCard>

            </div>

            {/* =================================================
                DEPARTMENT + TENURE INFO
            ================================================= */}

            <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">

                {/* DEPARTMENT */}

                <div className="xl:col-span-2">

                    <DashboardCard
                        title="Distribusi Karyawan per Department"
                        subtitle="8 department dengan jumlah karyawan terbesar"
                    >

                        <div className="h-[320px]">

                            {departmentData.length ===
                            0 ? (
                                <EmptyState />
                            ) : (
                                <ResponsiveContainer
                                    width="100%"
                                    height="100%"
                                >
                                    <BarChart
                                        data={
                                            departmentData
                                        }
                                        margin={{
                                            top: 10,
                                            right: 15,
                                            left: 0,
                                            bottom: 60
                                        }}
                                    >

                                        <CartesianGrid
                                            strokeDasharray="3 3"
                                            vertical={false}
                                        />

                                        <XAxis
                                            dataKey="name"
                                            angle={-35}
                                            textAnchor="end"
                                            interval={0}
                                            height={70}
                                            tick={{
                                                fontSize: 11
                                            }}
                                        />

                                        <YAxis
                                            allowDecimals={
                                                false
                                            }
                                        />

                                        <Tooltip
                                            formatter={(
                                                value
                                            ) => [
                                                `${formatNumber(
                                                    value
                                                )} karyawan`,
                                                'Total'
                                            ]}
                                        />

                                        <Bar
                                            dataKey="value"
                                            fill="#0891b2"
                                            radius={[
                                                5,
                                                5,
                                                0,
                                                0
                                            ]}
                                        />

                                    </BarChart>
                                </ResponsiveContainer>
                            )}

                        </div>

                    </DashboardCard>

                </div>

                {/* INSIGHT */}

                <DashboardCard
                    title="Ringkasan Masa Kerja"
                    subtitle="Informasi tambahan"
                >

                    <div className="space-y-3">

                        <InsightCard
                            icon={
                                <CalendarDays
                                    size={18}
                                />
                            }
                            label="Rata-rata seluruh karyawan"
                            value={formatYears(
                                stats.averageTenure
                            )}
                        />

                        {tenureByCategory
                            .slice(
                                0,
                                5
                            )
                            .map(
                                (item) => (
                                    <InsightCard
                                        key={
                                            item.category
                                        }
                                        icon={
                                            <Users
                                                size={
                                                    18
                                                }
                                            />
                                        }
                                        label={
                                            item.category
                                        }
                                        value={`${formatYears(
                                            item.averageTenure
                                        )} • ${formatNumber(
                                            item.total
                                        )} org`}
                                    />
                                )
                            )}

                    </div>

                </DashboardCard>

            </div>

            {/* =================================================
                ONE TABLE ONLY
            ================================================= */}

            <DashboardCard
                title="Karyawan Terbaru"
                subtitle="8 data terbaru berdasarkan perubahan data"
            >

                <div className="overflow-x-auto">

                    <table className="w-full min-w-[850px]">

                        <thead>
                            <tr className="border-b border-gray-200">

                                <th className="text-left px-3 py-3 text-xs font-semibold text-gray-500 uppercase">
                                    NIK
                                </th>

                                <th className="text-left px-3 py-3 text-xs font-semibold text-gray-500 uppercase">
                                    Nama
                                </th>

                                <th className="text-left px-3 py-3 text-xs font-semibold text-gray-500 uppercase">
                                    Posisi
                                </th>

                                <th className="text-left px-3 py-3 text-xs font-semibold text-gray-500 uppercase">
                                    Department
                                </th>

                                <th className="text-left px-3 py-3 text-xs font-semibold text-gray-500 uppercase">
                                    Section
                                </th>

                                <th className="text-left px-3 py-3 text-xs font-semibold text-gray-500 uppercase">
                                    Masa Kerja
                                </th>

                                <th className="text-left px-3 py-3 text-xs font-semibold text-gray-500 uppercase">
                                    Status
                                </th>

                            </tr>
                        </thead>

                        <tbody>

                            {recentEmployees.map(
                                (item) => (
                                    <tr
                                        key={
                                            item.id
                                        }
                                        className="border-b border-gray-100 hover:bg-gray-50"
                                    >

                                        <td className="px-3 py-3 text-sm text-gray-700">
                                            {
                                                item.national_id ||
                                                '-'
                                            }
                                        </td>

                                        <td className="px-3 py-3 text-sm font-medium text-gray-900">
                                            {
                                                item.name ||
                                                '-'
                                            }
                                        </td>

                                        <td className="px-3 py-3 text-sm text-gray-700">
                                            {
                                                item.position ||
                                                '-'
                                            }
                                        </td>

                                        <td className="px-3 py-3 text-sm text-gray-700">
                                            {
                                                item.department ||
                                                '-'
                                            }
                                        </td>

                                        <td className="px-3 py-3 text-sm text-gray-700">
                                            {
                                                item.section ||
                                                '-'
                                            }
                                        </td>

                                        <td className="px-3 py-3 text-sm text-gray-700">
                                            {formatYears(
                                                calculateTenureYears(
                                                    item.join_date
                                                )
                                            )}
                                        </td>

                                        <td className="px-3 py-3">

                                            <StatusBadge
                                                status={
                                                    item.employment_status
                                                }
                                            />

                                        </td>

                                    </tr>
                                )
                            )}

                        </tbody>

                    </table>

                    {recentEmployees.length ===
                        0 && (
                        <EmptyState />
                    )}

                </div>

            </DashboardCard>

        </div>
    );
};

/*
|--------------------------------------------------------------------------
| STAT CARD
|--------------------------------------------------------------------------
*/

const StatCard = ({
    title,
    value,
    subtitle,
    icon,
    iconClass
}) => {
    return (
        <div className="bg-white border border-gray-200 rounded-xl shadow-sm p-4 sm:p-5">

            <div className="flex items-start justify-between gap-3">

                <div className="min-w-0">

                    <p className="text-xs sm:text-sm text-gray-500 truncate">
                        {title}
                    </p>

                    <p className="text-2xl sm:text-3xl font-bold text-gray-900 mt-1">
                        {value}
                    </p>

                    <p className="text-xs text-gray-400 mt-1">
                        {subtitle}
                    </p>

                </div>

                <div
                    className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${iconClass}`}
                >
                    {icon}
                </div>

            </div>

        </div>
    );
};

/*
|--------------------------------------------------------------------------
| DASHBOARD CARD
|--------------------------------------------------------------------------
*/

const DashboardCard = ({
    title,
    subtitle,
    children,
    action
}) => {
    return (
        <section className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">

            <div className="px-4 sm:px-5 py-4 border-b border-gray-100 flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">

                <div className="min-w-0">

                    <h2 className="font-semibold text-gray-800">
                        {title}
                    </h2>

                    {subtitle && (
                        <p className="text-xs sm:text-sm text-gray-400 mt-1">
                            {subtitle}
                        </p>
                    )}

                </div>

                {action}

            </div>

            <div className="p-4 sm:p-5">
                {children}
            </div>

        </section>
    );
};

/*
|--------------------------------------------------------------------------
| INSIGHT CARD
|--------------------------------------------------------------------------
*/

const InsightCard = ({
    icon,
    label,
    value
}) => {
    return (
        <div className="flex items-center gap-3 p-3 rounded-lg bg-gray-50">

            <div className="w-9 h-9 rounded-lg bg-cyan-100 text-cyan-600 flex items-center justify-center flex-shrink-0">
                {icon}
            </div>

            <div className="min-w-0 flex-1">

                <p className="text-xs text-gray-500 truncate">
                    {label}
                </p>

                <p className="text-sm font-semibold text-gray-800 mt-0.5">
                    {value}
                </p>

            </div>

        </div>
    );
};

/*
|--------------------------------------------------------------------------
| STATUS BADGE
|--------------------------------------------------------------------------
*/

const StatusBadge = ({
    status
}) => {
    const classes = {
        Tetap:
            'bg-green-100 text-green-700',
        Kontrak:
            'bg-yellow-100 text-yellow-700',
        Magang:
            'bg-blue-100 text-blue-700',
        Resign:
            'bg-red-100 text-red-700'
    };

    return (
        <span
            className={`inline-flex px-2.5 py-1 rounded-full text-xs font-medium ${
                classes[status] ||
                'bg-gray-100 text-gray-600'
            }`}
        >
            {status || '-'}
        </span>
    );
};

/*
|--------------------------------------------------------------------------
| EMPTY
|--------------------------------------------------------------------------
*/

const EmptyState = () => {
    return (
        <div className="h-full min-h-[180px] flex items-center justify-center text-sm text-gray-400">
            Belum ada data
        </div>
    );
};

export default Dashboard;


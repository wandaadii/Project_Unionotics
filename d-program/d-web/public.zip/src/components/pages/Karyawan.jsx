import React, {
    useCallback,
    useEffect,
    useRef,
    useState
} from 'react';

import Buttonv1 from '../button/Buttonv1';

const API_URL = '/api/karyawan';

/*
|--------------------------------------------------------------------------
| ORGANIZATION LEVEL
|--------------------------------------------------------------------------
*/

const ORGANIZATION_LEVELS = [
    'division',
    'sub_division',
    'department',
    'sub_department',
    'section',
    'sub_section',
    'line',
    'sub_line'
];

/*
|--------------------------------------------------------------------------
| STRUKTUR ORGANISASI OTICS
|--------------------------------------------------------------------------
*/

const organizationPaths = [
    // =====================================================
    // QAD
    // =====================================================

    {
        division: 'QAD',
        sub_division: 'QAD',
        department: 'PuD',
        sub_department: 'PuD',
        section: 'Purchasing',
        sub_section: 'Purchasing',
        line: 'Purchasing',
        sub_line: 'Purchasing'
    },

    {
        division: 'QAD',
        sub_division: 'QAD',
        department: 'QAD',
        sub_department: 'QAD',
        section: 'QC Plant 1',
        sub_section: 'QC Plant 1',
        line: 'QC Plant 1',
        sub_line: 'QC Plant 1'
    },

    {
        division: 'QAD',
        sub_division: 'QAD',
        department: 'QAD',
        sub_department: 'QAD',
        section: 'QC Plant 2',
        sub_section: 'QC Plant 2',
        line: 'QC Plant 2',
        sub_line: 'QC Plant 2'
    },

    {
        division: 'QAD',
        sub_division: 'QAD',
        department: 'QAD',
        sub_department: 'QAD',
        section: 'QA',
        sub_section: 'QA',
        line: 'QA',
        sub_line: 'QA'
    },

    {
        division: 'QAD',
        sub_division: 'QAD',
        department: 'QAD',
        sub_department: 'QAD',
        section: 'EXIM',
        sub_section: 'EXIM',
        line: 'EXIM',
        sub_line: 'EXIM'
    },

    {
        division: 'QAD',
        sub_division: 'QAD',
        department: 'QAD',
        sub_department: 'QAD',
        section: 'Sales Marketing',
        sub_section: 'Sales Marketing',
        line: 'Sales Marketing',
        sub_line: 'Sales Marketing'
    },

    // =====================================================
    // PRODUCTION PLANT 1 - PRODUCTION 1
    // =====================================================

    {
        division: 'Production Plant 1',
        sub_division: 'Production Plant 1',
        department: 'Production 1',
        sub_department: 'Production 1',
        section: 'PG1',
        sub_section: 'PG-1',
        line: 'PG1-1',
        sub_line: 'PG1-1'
    },

    {
        division: 'Production Plant 1',
        sub_division: 'Production Plant 1',
        department: 'Production 1',
        sub_department: 'Production 1',
        section: 'PG1',
        sub_section: 'PG-1',
        line: 'PG1-2',
        sub_line: 'PG1-2'
    },

    {
        division: 'Production Plant 1',
        sub_division: 'Production Plant 1',
        department: 'Production 1',
        sub_department: 'Production 1',
        section: 'PG2-3',
        sub_section: 'PG-2.3',
        line: 'PG2-3',
        sub_line: 'PG2-3'
    },

    // =====================================================
    // PRODUCTION PLANT 1 - MTC & ENG
    // =====================================================

    {
        division: 'Production Plant 1',
        sub_division: 'MTC & ENG',
        department: 'Engineering',
        sub_department: 'Engineering',
        section: 'EWD New Project',
        sub_section: 'EWD New Project',
        line: 'New Project',
        sub_line: 'New Project'
    },

    {
        division: 'Production Plant 1',
        sub_division: 'MTC & ENG',
        department: 'Engineering',
        sub_department: 'Engineering',
        section: 'EWD Pr ENG',
        sub_section: 'EWD Pr ENG',
        line: 'Kaizen Plant 1',
        sub_line: 'Kaizen Plant 1'
    },

    {
        division: 'Production Plant 1',
        sub_division: 'MTC & ENG',
        department: 'Engineering',
        sub_department: 'Engineering',
        section: 'EWD Pr ENG',
        sub_section: 'EWD Pr ENG',
        line: 'Kaizen Plant 2',
        sub_line: 'Kaizen Plant 2'
    },

    {
        division: 'Production Plant 1',
        sub_division: 'MTC & ENG',
        department: 'Engineering',
        sub_department: 'Engineering',
        section: 'Cutting Tool',
        sub_section: 'Cutting Tool',
        line: 'Cutting Tool',
        sub_line: 'Cutting Tool'
    },

    {
        division: 'Production Plant 1',
        sub_division: 'MTC & ENG',
        department: 'Maintenance',
        sub_department: 'Maintenance',
        section: 'MTC Plant 1',
        sub_section: 'MTC Plant 1',
        line: 'M/E',
        sub_line: 'M/E Line'
    },

    {
        division: 'Production Plant 1',
        sub_division: 'MTC & ENG',
        department: 'Maintenance',
        sub_department: 'Maintenance',
        section: 'MTC Plant 1',
        sub_section: 'MTC Plant 1',
        line: 'MTC Plant 1',
        sub_line: 'Maintenance Plant 1'
    },

    {
        division: 'Production Plant 1',
        sub_division: 'MTC & ENG',
        department: 'Maintenance',
        sub_department: 'Maintenance',
        section: 'MTC Plant 2',
        sub_section: 'MTC Plant 2',
        line: 'MTC Plant 2',
        sub_line: 'Maintenance Plant 2'
    },

    // =====================================================
    // PRODUCTION PLANT 2
    // =====================================================

    {
        division: 'Production Plant 2',
        sub_division: 'Production Plant 2',
        department: 'Production 3',
        sub_department: 'Production 3',
        section: 'PG3-1',
        sub_section: 'PG-3.1',
        line: 'PG3-1',
        sub_line: 'PG3-1'
    },

    {
        division: 'Production Plant 2',
        sub_division: 'Production Plant 2',
        department: 'Production 3',
        sub_department: 'Production 3',
        section: 'PG3-2',
        sub_section: 'PG-3.2',
        line: 'PG3-2',
        sub_line: 'PG3-2'
    },

    // =====================================================
    // PCD
    // =====================================================

    {
        division: 'Production Plant 2',
        sub_division: 'Production Plant 2',
        department: 'PCD',
        sub_department: 'PCD',
        section: 'PCD',
        sub_section: 'PCD',
        line: 'PCD',
        sub_line: 'PCD'
    },

    {
        division: 'Production Plant 2',
        sub_division: 'Production Plant 2',
        department: 'PCD',
        sub_department: 'PCD',
        section: 'PCD',
        sub_section: 'PCD',
        line: 'PCD Plant 2',
        sub_line: 'PCD Plant 2'
    },

    // =====================================================
    // TPS
    // =====================================================

    {
        division: 'TPS',
        sub_division: 'TPS',
        department: 'TPS',
        sub_department: 'TPS',
        section: 'TPS Plant 1',
        sub_section: 'TPS Plant 1',
        line: 'TPS Plant 1',
        sub_line: 'TPS Plant 1'
    },

    {
        division: 'TPS',
        sub_division: 'TPS',
        department: 'TPS',
        sub_department: 'TPS',
        section: 'TPS Plant 2',
        sub_section: 'TPS Plant 2',
        line: 'TPS Plant 2',
        sub_line: 'TPS Plant 2'
    },

    // =====================================================
    // GENERAL ADMIN
    // =====================================================

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'Accounting',
        sub_department: 'Accounting',
        section: 'Accounting',
        sub_section: 'Accounting',
        line: 'Accounting',
        sub_line: 'Accounting'
    },

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'HR & GA',
        sub_department: 'HR & GA',
        section: 'IT Support',
        sub_section: 'IT Support',
        line: 'IT Support',
        sub_line: 'IT Support'
    },

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'HR & GA',
        sub_department: 'HR & GA',
        section: 'Safety',
        sub_section: 'Safety',
        line: 'Safety',
        sub_line: 'Safety'
    },

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'HR & GA',
        sub_department: 'HR & GA',
        section: 'HR & Training',
        sub_section: 'HR & Training',
        line: 'HR Admin',
        sub_line: 'Security'
    },

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'HR & GA',
        sub_department: 'HR & GA',
        section: 'HR & Training',
        sub_section: 'HR & Training',
        line: 'HR Admin',
        sub_line: 'HR Admin'
    },

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'HR & GA',
        sub_department: 'HR & GA',
        section: 'HR & Training',
        sub_section: 'HR & Training',
        line: 'HR Training',
        sub_line: 'HR Training'
    },

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'HR & GA',
        sub_department: 'HR & GA',
        section: 'PGA Plant 2',
        sub_section: 'PGA Plant 2',
        line: 'PGA Plant 2',
        sub_line: 'PGA Plant 2'
    },

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'HR & GA',
        sub_department: 'HR & GA',
        section: 'Secretary',
        sub_section: 'Secretary',
        line: 'Secretary',
        sub_line: 'Secretary'
    },

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'HR & GA',
        sub_department: 'HR & GA',
        section: 'Supplier Dev',
        sub_section: 'Supplier Dev',
        line: 'Supplier Dev',
        sub_line: 'Supplier Dev'
    },

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'HR & GA',
        sub_department: 'HR & GA',
        section: 'Utility',
        sub_section: 'Utility',
        line: 'BJS',
        sub_line: 'BJS'
    },

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'HR & GA',
        sub_department: 'HR & GA',
        section: 'Utility',
        sub_section: 'Utility',
        line: 'Utility Plant 2',
        sub_line: 'Utility Plant 2'
    },

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'HR & GA',
        sub_department: 'HR & GA',
        section: 'Payroll',
        sub_section: 'Payroll',
        line: 'Payroll',
        sub_line: 'Payroll'
    },

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'HR & GA',
        sub_department: 'HR & GA',
        section: 'IR',
        sub_section: 'IR',
        line: 'IR',
        sub_line: 'IR'
    },

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'HR & GA',
        sub_department: 'HR & GA',
        section: 'ISO & ENVY',
        sub_section: 'ISO & ENVY',
        line: 'ISO & ENVY',
        sub_line: 'ISO & ENVY'
    },

    {
        division: 'General Admin',
        sub_division: 'General Admin',
        department: 'HR & GA',
        sub_department: 'HR & GA',
        section: 'GA',
        sub_section: 'GA',
        line: 'GA',
        sub_line: 'GA'
    }
];

/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/

const normalizeDate = (value) => {
    if (!value) {
        return '';
    }

    if (typeof value === 'string') {
        const trimmed = value.trim();

        if (
            /^\d{4}-\d{2}-\d{2}$/.test(
                trimmed
            )
        ) {
            return trimmed;
        }

        if (
            /^\d{4}-\d{2}-\d{2}T/.test(
                trimmed
            )
        ) {
            return trimmed.substring(0, 10);
        }
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return '';
    }

    return date.toISOString().split('T')[0];
};

const toNullable = (value) => {
    if (
        value === '' ||
        value === undefined ||
        value === null
    ) {
        return null;
    }

    return value;
};

const toNullableNumber = (value) => {
    if (
        value === '' ||
        value === undefined ||
        value === null
    ) {
        return null;
    }

    const number = Number(value);

    return Number.isNaN(number)
        ? null
        : number;
};

/*
|--------------------------------------------------------------------------
| ORGANIZATION DROPDOWN HELPER
|--------------------------------------------------------------------------
*/

const getOrganizationOptions = (
    level,
    formData
) => {
    const index =
        ORGANIZATION_LEVELS.indexOf(level);

    if (index === -1) {
        return [];
    }

    const parentLevels =
        ORGANIZATION_LEVELS.slice(0, index);

    const filtered =
        organizationPaths.filter((path) => {
            return parentLevels.every(
                (parent) => {
                    const selected =
                        formData[parent];

                    if (!selected) {
                        return true;
                    }

                    return (
                        path[parent] ===
                        selected
                    );
                }
            );
        });

    return [
        ...new Set(
            filtered
                .map(
                    (item) =>
                        item[level]
                )
                .filter(Boolean)
        )
    ].sort((a, b) =>
        String(a).localeCompare(
            String(b)
        )
    );
};

const isOrganizationDisabled = (
    level,
    formData
) => {
    const index =
        ORGANIZATION_LEVELS.indexOf(level);

    if (index <= 0) {
        return false;
    }

    const parentLevel =
        ORGANIZATION_LEVELS[
            index - 1
        ];

    return !formData[parentLevel];
};

/*
|--------------------------------------------------------------------------
| DEFAULT FORM
|--------------------------------------------------------------------------
*/

const defaultFormData = {
    photo: '',
    national_id: '',
    name: '',
    place_of_birth: '',
    date_of_birth: '',

    gender: 'Laki-laki',
    blood_type: '',
    religion: '',
    marital_status: 'Belum Kawin',
    number_of_children: 0,

    ktp_address: '',
    residential_address: '',
    phone_number: '',
    email: '',
    emergency_contact: '',

    last_education: '',
    educational_institution: '',
    graduation_year: '',
    major: '',

    employee_number: '',

    plant: '',
    division: '',
    sub_division: '',
    department: '',
    sub_department: '',
    section: '',
    sub_section: '',
    line: '',
    sub_line: '',
    line_status: '',
    position: '',

    join_date: '',
    employment_status: 'Kontrak',

    basic_salary: '',
    allowance: '',

    bank_account_number: '',
    bank_name: '',

    health_insurance_number: '',
    employment_insurance_number: '',

    medical_history: '',
    other_notes: ''
};

/*
|--------------------------------------------------------------------------
| REUSABLE INPUT
|--------------------------------------------------------------------------
*/

const InputField = ({
    label,
    name,
    value,
    onChange,
    type = 'text',
    required = false,
    min,
    max,
    step,
    placeholder = ''
}) => {
    return (
        <div>
            <label className="block text-sm font-medium text-gray-700">
                {label}

                {required && (
                    <span className="text-red-500">
                        {' '}*
                    </span>
                )}
            </label>

            <input
                type={type}
                name={name}
                value={
                    value ??
                    ''
                }
                onChange={onChange}
                required={required}
                min={min}
                max={max}
                step={step}
                placeholder={placeholder}
                className="mt-1 block w-full border border-gray-300 rounded-md p-3 bg-white focus:outline-none focus:ring-2 focus:ring-cyan-300 focus:border-cyan-400"
            />
        </div>
    );
};

const TextAreaField = ({
    label,
    name,
    value,
    onChange,
    rows = 3
}) => {
    return (
        <div>
            <label className="block text-sm font-medium text-gray-700">
                {label}
            </label>

            <textarea
                name={name}
                value={
                    value ??
                    ''
                }
                onChange={onChange}
                rows={rows}
                className="mt-1 block w-full border border-gray-300 rounded-md p-3 bg-white focus:outline-none focus:ring-2 focus:ring-cyan-300 focus:border-cyan-400"
            />
        </div>
    );
};

const SelectField = ({
    label,
    name,
    value,
    onChange,
    options,
    disabled = false
}) => {
    return (
        <div>
            <label className="block text-sm font-medium text-gray-700">
                {label}
            </label>

            <select
                name={name}
                value={value ?? ''}
                onChange={onChange}
                disabled={disabled}
                className={`mt-1 block w-full border border-gray-300 rounded-md p-3 bg-white focus:outline-none focus:ring-2 focus:ring-cyan-300 focus:border-cyan-400 ${
                    disabled
                        ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                        : ''
                }`}
            >
                {options.map(
                    (option) => (
                        <option
                            key={
                                option.value
                            }
                            value={
                                option.value
                            }
                        >
                            {
                                option.label
                            }
                        </option>
                    )
                )}
            </select>
        </div>
    );
};

/*
|--------------------------------------------------------------------------
| SEARCHABLE SELECT
|--------------------------------------------------------------------------
*/

const SearchableSelect = ({
    label,
    name,
    placeholder,
    options = [],
    value,
    onChange,
    disabled = false
}) => {
    const [open, setOpen] =
        useState(false);

    const [query, setQuery] =
        useState('');

    const ref = useRef(null);

    useEffect(() => {
        const handleOutside = (
            event
        ) => {
            if (
                ref.current &&
                !ref.current.contains(
                    event.target
                )
            ) {
                setOpen(false);
                setQuery('');
            }
        };

        document.addEventListener(
            'mousedown',
            handleOutside
        );

        return () => {
            document.removeEventListener(
                'mousedown',
                handleOutside
            );
        };
    }, []);

    const filteredOptions =
        options.filter((option) =>
            String(option)
                .toLowerCase()
                .includes(
                    query.toLowerCase()
                )
        );

    const handleSelect = (
        selected
    ) => {
        onChange({
            target: {
                name,
                value: selected
            }
        });

        setOpen(false);
        setQuery('');
    };

    const handleClear = (event) => {
        event.stopPropagation();

        onChange({
            target: {
                name,
                value: ''
            }
        });

        setQuery('');
    };

    return (
        <div ref={ref}>
            <label className="block text-sm font-medium text-gray-700">
                {label}
            </label>

            <div className="relative mt-1">

                <button
                    type="button"
                    disabled={disabled}
                    onClick={() =>
                        setOpen(
                            (prev) =>
                                !prev
                        )
                    }
                    className={`w-full min-h-[50px] border border-gray-300 rounded-md px-3 py-3 flex items-center justify-between text-left ${
                        disabled
                            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            : 'bg-white hover:border-cyan-400'
                    }`}
                >
                    <span
                        className={`truncate ${
                            value
                                ? 'text-gray-900'
                                : 'text-gray-400'
                        }`}
                    >
                        {value ||
                            placeholder}
                    </span>

                    <span className="ml-2 text-gray-400">
                        {open
                            ? '▲'
                            : '▼'}
                    </span>
                </button>

                {open && !disabled && (
                    <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-gray-200 rounded-md shadow-xl z-[100] overflow-hidden">

                        <div className="p-2 border-b bg-gray-50">
                            <input
                                type="text"
                                value={query}
                                onChange={(
                                    event
                                ) =>
                                    setQuery(
                                        event
                                            .target
                                            .value
                                    )
                                }
                                placeholder="Cari..."
                                autoFocus
                                className="w-full border border-gray-300 rounded-md p-2 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-300"
                            />
                        </div>

                        <div className="max-h-56 overflow-y-auto">

                            {value && (
                                <button
                                    type="button"
                                    onClick={
                                        handleClear
                                    }
                                    className="w-full text-left px-3 py-2 text-sm text-red-500 hover:bg-red-50 border-b"
                                >
                                    ✕ Hapus Pilihan
                                </button>
                            )}

                            {filteredOptions.length >
                            0 ? (
                                filteredOptions.map(
                                    (
                                        option
                                    ) => (
                                        <button
                                            type="button"
                                            key={
                                                option
                                            }
                                            onClick={() =>
                                                handleSelect(
                                                    option
                                                )
                                            }
                                            className={`w-full text-left px-3 py-2 text-sm hover:bg-cyan-50 ${
                                                option ===
                                                value
                                                    ? 'bg-cyan-100 text-cyan-700 font-medium'
                                                    : 'text-gray-700'
                                            }`}
                                        >
                                            {
                                                option
                                            }
                                        </button>
                                    )
                                )
                            ) : (
                                <div className="px-3 py-4 text-sm text-gray-400 text-center">
                                    Tidak ada opsi
                                </div>
                            )}

                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

/*
|--------------------------------------------------------------------------
| KARYAWAN
|--------------------------------------------------------------------------
*/

const Karyawan = () => {
    const [
        activeTab,
        setActiveTab
    ] = useState('list');

    const [
        karyawan,
        setKaryawan
    ] = useState([]);

    const [
        loading,
        setLoading
    ] = useState(false);

    const [
        saving,
        setSaving
    ] = useState(false);

    const [
        editingId,
        setEditingId
    ] = useState(null);

    const [
        selectedKaryawan,
        setSelectedKaryawan
    ] = useState(null);

    const [
        showDetailModal,
        setShowDetailModal
    ] = useState(false);

    const [
        formData,
        setFormData
    ] = useState({
        ...defaultFormData
    });

    const [
        filters,
        setFilters
    ] = useState({
        national_id: '',
        name: '',
        plant: '',
        division: '',
        sub_division: '',
        department: '',
        sub_department: '',
        section: '',
        sub_section: '',
        line: '',
        sub_line: '',
        position: '',
        employment_status: ''
    });

    const [
        currentPage,
        setCurrentPage
    ] = useState(1);

    const [
        rowsPerPage,
        setRowsPerPage
    ] = useState(10);

    /*
    |--------------------------------------------------------------------------
    | FETCH
    |--------------------------------------------------------------------------
    */

    const fetchKaryawan =
        useCallback(
            async () => {
                setLoading(true);

                try {
                    const response =
                        await fetch(
                            API_URL
                        );

                    if (
                        !response.ok
                    ) {
                        throw new Error(
                            `HTTP ${response.status}`
                        );
                    }

                    const data =
                        await response.json();

                    setKaryawan(
                        Array.isArray(
                            data
                        )
                            ? data
                            : []
                    );
                } catch (
                    error
                ) {
                    console.error(
                        error
                    );

                    alert(
                        'Gagal mengambil data karyawan'
                    );
                } finally {
                    setLoading(false);
                }
            },
            []
        );

    useEffect(() => {
        fetchKaryawan();
    }, [fetchKaryawan]);

    /*
    |--------------------------------------------------------------------------
    | FILTER
    |--------------------------------------------------------------------------
    */

    const getUniqueValues =
        useCallback(
            (field) => {
                return [
                    ...new Set(
                        karyawan
                            .map(
                                (
                                    item
                                ) =>
                                    item[
                                        field
                                    ]
                            )
                            .filter(
                                (
                                    value
                                ) =>
                                    value !==
                                        null &&
                                    value !==
                                        undefined &&
                                    String(
                                        value
                                    ).trim() !==
                                        ''
                            )
                    )
                ].sort(
                    (a, b) =>
                        String(
                            a
                        ).localeCompare(
                            String(
                                b
                            )
                        )
                );
            },
            [karyawan]
        );

    const filteredKaryawan =
        karyawan.filter(
            (item) => {
                const textFields = [
                    'national_id',
                    'name'
                ];

                const selectFields = [
                    'plant',
                    'division',
                    'sub_division',
                    'department',
                    'sub_department',
                    'section',
                    'sub_section',
                    'line',
                    'sub_line',
                    'position'
                ];

                const textMatch =
                    textFields.every(
                        (field) => {
                            if (
                                !filters[
                                    field
                                ]
                            ) {
                                return true;
                            }

                            return String(
                                item[
                                    field
                                ] || ''
                            )
                                .toLowerCase()
                                .includes(
                                    filters[
                                        field
                                    ].toLowerCase()
                                );
                        }
                    );

                const selectMatch =
                    selectFields.every(
                        (field) => {
                            if (
                                !filters[
                                    field
                                ]
                            ) {
                                return true;
                            }

                            return String(
                                item[
                                    field
                                ] || ''
                            )
                                .toLowerCase()
                                .includes(
                                    filters[
                                        field
                                    ].toLowerCase()
                                );
                        }
                    );

                const statusMatch =
                    !filters.employment_status ||
                    String(
                        item.employment_status ||
                            ''
                    ).toLowerCase() ===
                        filters.employment_status.toLowerCase();

                return (
                    textMatch &&
                    selectMatch &&
                    statusMatch
                );
            }
        );

    /*
    |--------------------------------------------------------------------------
    | PAGINATION
    |--------------------------------------------------------------------------
    */

    const totalPages =
        Math.ceil(
            filteredKaryawan.length /
                rowsPerPage
        );

    const safeTotalPages =
        totalPages || 0;

    const indexOfLastRow =
        currentPage *
        rowsPerPage;

    const indexOfFirstRow =
        indexOfLastRow -
        rowsPerPage;

    const currentRows =
        filteredKaryawan.slice(
            indexOfFirstRow,
            indexOfLastRow
        );

    useEffect(() => {
        if (
            totalPages === 0
        ) {
            setCurrentPage(1);
            return;
        }

        if (
            currentPage >
            totalPages
        ) {
            setCurrentPage(
                totalPages
            );
        }
    }, [
        currentPage,
        totalPages
    ]);

    /*
    |--------------------------------------------------------------------------
    | HANDLER
    |--------------------------------------------------------------------------
    */

    const handleFilterChange =
        useCallback(
            (event) => {
                const {
                    name,
                    value
                } =
                    event.target;

                setFilters(
                    (prev) => ({
                        ...prev,
                        [name]:
                            value
                    })
                );

                setCurrentPage(
                    1
                );
            },
            []
        );

    const handleChange = (
        event
    ) => {
        const {
            name,
            value
        } = event.target;

        setFormData(
            (prev) => ({
                ...prev,
                [name]:
                    value
            })
        );
    };

    const handleOrganizationChange =
        (event) => {
            const {
                name,
                value
            } =
                event.target;

            setFormData(
                (prev) => {
                    const next = {
                        ...prev,
                        [name]:
                            value
                    };

                    const index =
                        ORGANIZATION_LEVELS.indexOf(
                            name
                        );

                    if (
                        index >=
                        0
                    ) {
                        ORGANIZATION_LEVELS
                            .slice(
                                index +
                                    1
                            )
                            .forEach(
                                (
                                    level
                                ) => {
                                    next[
                                        level
                                    ] =
                                        '';
                                }
                            );
                    }

                    return next;
                }
            );
        };

    const resetFilters =
        () => {
            setFilters({
                national_id:
                    '',
                name: '',
                plant: '',
                division: '',
                sub_division:
                    '',
                department:
                    '',
                sub_department:
                    '',
                section: '',
                sub_section:
                    '',
                line: '',
                sub_line: '',
                position: '',
                employment_status:
                    ''
            });

            setCurrentPage(
                1
            );
        };

    const resetForm = () => {
        setFormData({
            ...defaultFormData
        });

        setEditingId(null);
    };

    /*
    |--------------------------------------------------------------------------
    | SUBMIT
    |--------------------------------------------------------------------------
    */

    const handleSubmit =
        async (event) => {
            event.preventDefault();

            setSaving(true);

            try {
                const payload = {
                    photo: toNullable(
                        formData.photo
                    ),

                    national_id:
                        toNullable(
                            formData.national_id
                        ),

                    name: toNullable(
                        formData.name
                    ),

                    place_of_birth:
                        toNullable(
                            formData.place_of_birth
                        ),

                    date_of_birth:
                        formData.date_of_birth
                            ? normalizeDate(
                                  formData.date_of_birth
                              )
                            : null,

                    gender:
                        toNullable(
                            formData.gender
                        ),

                    blood_type:
                        toNullable(
                            formData.blood_type
                        ),

                    religion:
                        toNullable(
                            formData.religion
                        ),

                    marital_status:
                        toNullable(
                            formData.marital_status
                        ),

                    number_of_children:
                        toNullableNumber(
                            formData.number_of_children
                        ),

                    ktp_address:
                        toNullable(
                            formData.ktp_address
                        ),

                    residential_address:
                        toNullable(
                            formData.residential_address
                        ),

                    phone_number:
                        toNullable(
                            formData.phone_number
                        ),

                    email: toNullable(
                        formData.email
                    ),

                    emergency_contact:
                        toNullable(
                            formData.emergency_contact
                        ),

                    last_education:
                        toNullable(
                            formData.last_education
                        ),

                    educational_institution:
                        toNullable(
                            formData.educational_institution
                        ),

                    graduation_year:
                        toNullableNumber(
                            formData.graduation_year
                        ),

                    major: toNullable(
                        formData.major
                    ),

                    employee_number:
                        toNullable(
                            formData.employee_number
                        ),

                    /*
                    | ORGANISASI
                    */

                    plant: toNullable(
                        formData.plant
                    ),

                    division:
                        toNullable(
                            formData.division
                        ),

                    sub_division:
                        toNullable(
                            formData.sub_division
                        ),

                    department:
                        toNullable(
                            formData.department
                        ),

                    sub_department:
                        toNullable(
                            formData.sub_department
                        ),

                    section:
                        toNullable(
                            formData.section
                        ),

                    sub_section:
                        toNullable(
                            formData.sub_section
                        ),

                    line: toNullable(
                        formData.line
                    ),

                    sub_line:
                        toNullable(
                            formData.sub_line
                        ),

                    line_status:
                        toNullable(
                            formData.line_status
                        ),

                    position:
                        toNullable(
                            formData.position
                        ),

                    join_date:
                        formData.join_date
                            ? normalizeDate(
                                  formData.join_date
                              )
                            : null,

                    employment_status:
                        toNullable(
                            formData.employment_status
                        ) ||
                        'Kontrak',

                    basic_salary:
                        toNullableNumber(
                            formData.basic_salary
                        ),

                    allowance:
                        toNullableNumber(
                            formData.allowance
                        ),

                    bank_account_number:
                        toNullable(
                            formData.bank_account_number
                        ),

                    bank_name:
                        toNullable(
                            formData.bank_name
                        ),

                    health_insurance_number:
                        toNullable(
                            formData.health_insurance_number
                        ),

                    employment_insurance_number:
                        toNullable(
                            formData.employment_insurance_number
                        ),

                    medical_history:
                        toNullable(
                            formData.medical_history
                        ),

                    other_notes:
                        toNullable(
                            formData.other_notes
                        )
                };

                const url =
                    editingId
                        ? `${API_URL}/${editingId}`
                        : API_URL;

                const method =
                    editingId
                        ? 'PUT'
                        : 'POST';

                const response =
                    await fetch(
                        url,
                        {
                            method,
                            headers: {
                                'Content-Type':
                                    'application/json'
                            },
                            body: JSON.stringify(
                                payload
                            )
                        }
                    );

                const result =
                    await response.json();

                if (
                    !response.ok
                ) {
                    throw new Error(
                        result.error ||
                            result.message ||
                            'Gagal menyimpan data'
                    );
                }

                alert(
                    editingId
                        ? 'Data karyawan berhasil diperbarui'
                        : 'Data karyawan berhasil ditambahkan'
                );

                resetForm();

                await fetchKaryawan();

                setActiveTab(
                    'list'
                );
            } catch (
                error
            ) {
                console.error(
                    error
                );

                alert(
                    `Gagal menyimpan data:\n${error.message}`
                );
            } finally {
                setSaving(false);
            }
        };

    /*
    |--------------------------------------------------------------------------
    | EDIT
    |--------------------------------------------------------------------------
    */

    const handleEdit = (
        item
    ) => {
        setFormData({
            photo:
                item.photo || '',
            national_id:
                item.national_id ||
                '',
            name:
                item.name || '',
            place_of_birth:
                item.place_of_birth ||
                '',

            date_of_birth:
                normalizeDate(
                    item.date_of_birth
                ),

            gender:
                item.gender ||
                'Laki-laki',

            blood_type:
                item.blood_type ||
                '',

            religion:
                item.religion || '',

            marital_status:
                item.marital_status ||
                'Belum Kawin',

            number_of_children:
                item.number_of_children ??
                0,

            ktp_address:
                item.ktp_address ||
                '',

            residential_address:
                item.residential_address ||
                '',

            phone_number:
                item.phone_number ||
                '',

            email:
                item.email || '',

            emergency_contact:
                item.emergency_contact ||
                '',

            last_education:
                item.last_education ||
                '',

            educational_institution:
                item.educational_institution ||
                '',

            graduation_year:
                item.graduation_year ??
                '',

            major:
                item.major || '',

            employee_number:
                item.employee_number ||
                '',

            plant:
                item.plant || '',

            division:
                item.division || '',

            sub_division:
                item.sub_division ||
                '',

            department:
                item.department ||
                '',

            sub_department:
                item.sub_department ||
                '',

            section:
                item.section || '',

            sub_section:
                item.sub_section ||
                '',

            line:
                item.line || '',

            sub_line:
                item.sub_line ||
                '',

            line_status:
                item.line_status ||
                '',

            position:
                item.position ||
                '',

            join_date:
                normalizeDate(
                    item.join_date
                ),

            employment_status:
                item.employment_status ||
                'Kontrak',

            basic_salary:
                item.basic_salary ??
                '',

            allowance:
                item.allowance ??
                '',

            bank_account_number:
                item.bank_account_number ||
                '',

            bank_name:
                item.bank_name ||
                '',

            health_insurance_number:
                item.health_insurance_number ||
                '',

            employment_insurance_number:
                item.employment_insurance_number ||
                '',

            medical_history:
                item.medical_history ||
                '',

            other_notes:
                item.other_notes ||
                ''
        });

        setEditingId(
            item.id
        );

        setActiveTab(
            'form'
        );
    };

    /*
    |--------------------------------------------------------------------------
    | DELETE
    |--------------------------------------------------------------------------
    */

    const handleDelete =
        async (id) => {
            const confirmed =
                window.confirm(
                    'Yakin ingin menghapus data karyawan ini?'
                );

            if (!confirmed) {
                return;
            }

            try {
                const response =
                    await fetch(
                        `${API_URL}/${id}`,
                        {
                            method: 'DELETE'
                        }
                    );

                const result =
                    await response.json();

                if (
                    !response.ok
                ) {
                    throw new Error(
                        result.error ||
                            result.message ||
                            'Gagal menghapus data'
                    );
                }

                alert(
                    'Data karyawan berhasil dihapus'
                );

                await fetchKaryawan();
            } catch (
                error
            ) {
                console.error(
                    error
                );

                alert(
                    `Gagal menghapus data:\n${error.message}`
                );
            }
        };

    /*
    |--------------------------------------------------------------------------
    | DETAIL
    |--------------------------------------------------------------------------
    */

    const handleDetail =
        (item) => {
            setSelectedKaryawan(
                item
            );

            setShowDetailModal(
                true
            );
        };

    const closeDetailModal =
        () => {
            setShowDetailModal(
                false
            );

            setSelectedKaryawan(
                null
            );
        };

    /*
    |--------------------------------------------------------------------------
    | STATUS
    |--------------------------------------------------------------------------
    */

    const getStatusClass = (
        status
    ) => {
        switch (status) {
            case 'Tetap':
                return 'bg-green-100 text-green-700';

            case 'Kontrak':
                return 'bg-yellow-100 text-yellow-700';

            case 'Magang':
                return 'bg-blue-100 text-blue-700';

            case 'Resign':
                return 'bg-red-100 text-red-700';

            default:
                return 'bg-gray-100 text-gray-700';
        }
    };

    /*
    |--------------------------------------------------------------------------
    | ORGANIZATION OPTIONS
    |--------------------------------------------------------------------------
    */

    const divisionOptions =
        getOrganizationOptions(
            'division',
            formData
        );

    const subDivisionOptions =
        getOrganizationOptions(
            'sub_division',
            formData
        );

    const departmentOptions =
        getOrganizationOptions(
            'department',
            formData
        );

    const subDepartmentOptions =
        getOrganizationOptions(
            'sub_department',
            formData
        );

    const sectionOptions =
        getOrganizationOptions(
            'section',
            formData
        );

    const subSectionOptions =
        getOrganizationOptions(
            'sub_section',
            formData
        );

    const lineOptions =
        getOrganizationOptions(
            'line',
            formData
        );

    const subLineOptions =
        getOrganizationOptions(
            'sub_line',
            formData
        );

    /*
    |--------------------------------------------------------------------------
    | RENDER
    |--------------------------------------------------------------------------
    */

    return (
        <div className="w-full">

            {/* =================================================
                TAB
            ================================================= */}

            <div className="flex border-b border-gray-200 mb-5 overflow-x-auto">

                <button
                    type="button"
                    onClick={() =>
                        setActiveTab(
                            'list'
                        )
                    }
                    className={`whitespace-nowrap px-4 py-3 text-sm font-medium ${
                        activeTab ===
                        'list'
                            ? 'text-cyan-600 border-b-2 border-cyan-500'
                            : 'text-gray-500 hover:text-gray-700'
                    }`}
                >
                    📋 List Karyawan
                </button>

                <button
                    type="button"
                    onClick={() => {
                        resetForm();
                        setActiveTab(
                            'form'
                        );
                    }}
                    className={`whitespace-nowrap px-4 py-3 text-sm font-medium ${
                        activeTab ===
                        'form'
                            ? 'text-cyan-600 border-b-2 border-cyan-500'
                            : 'text-gray-500 hover:text-gray-700'
                    }`}
                >
                    ➕ Tambah Karyawan
                </button>

            </div>

            {/* =================================================
                LIST
            ================================================= */}

            {activeTab ===
            'list' ? (
                <div>

                    {/* FILTER */}

                    <div className="mb-5 bg-white border border-gray-200 rounded-xl shadow-sm p-4">

                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">

                            <div>
                                <h3 className="font-semibold text-gray-800">
                                    Filter Karyawan
                                </h3>

                                <p className="text-xs text-gray-500 mt-1">
                                    Gunakan filter untuk
                                    mencari data lebih cepat.
                                </p>
                            </div>

                            <button
                                type="button"
                                onClick={
                                    resetFilters
                                }
                                className="self-start sm:self-auto text-sm text-cyan-600 hover:text-cyan-800"
                            >
                                Reset Filter
                            </button>

                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">

                            <FilterInput
                                name="national_id"
                                placeholder="Cari NIK..."
                                value={
                                    filters.national_id
                                }
                                onChange={
                                    handleFilterChange
                                }
                            />

                            <FilterInput
                                name="name"
                                placeholder="Cari Nama..."
                                value={
                                    filters.name
                                }
                                onChange={
                                    handleFilterChange
                                }
                            />

                            {[
                                'plant',
                                'division',
                                'sub_division',
                                'department',
                                'sub_department',
                                'section',
                                'sub_section',
                                'line',
                                'sub_line',
                                'position',
                                'employment_status'
                            ].map(
                                (field) => {
                                    const labels = {
                                        plant: 'Semua Plant',
                                        division: 'Semua Division',
                                        sub_division:
                                            'Semua Sub Division',
                                        department:
                                            'Semua Department',
                                        sub_department:
                                            'Semua Sub Department',
                                        section: 'Semua Section',
                                        sub_section:
                                            'Semua Sub Section',
                                        line: 'Semua Line',
                                        sub_line:
                                            'Semua Sub Line',
                                        position:
                                            'Semua Jabatan',
                                        employment_status:
                                            'Semua Status'
                                    };

                                    return (
                                        <SearchableSelect
                                            key={
                                                field
                                            }
                                            label=""
                                            name={
                                                field
                                            }
                                            placeholder={
                                                labels[
                                                    field
                                                ]
                                            }
                                            options={getUniqueValues(
                                                field
                                            )}
                                            value={
                                                filters[
                                                    field
                                                ]
                                            }
                                            onChange={
                                                handleFilterChange
                                            }
                                        />
                                    );
                                }
                            )}

                        </div>

                        <div className="mt-4 pt-4 border-t border-gray-100">

                            <span className="text-sm text-gray-600">
                                {filteredKaryawan.length >
                                0
                                    ? `Menampilkan ${
                                          indexOfFirstRow +
                                          1
                                      } - ${Math.min(
                                          indexOfLastRow,
                                          filteredKaryawan.length
                                      )} dari ${filteredKaryawan.length} data`
                                    : 'Menampilkan 0 data'}
                            </span>

                        </div>
                    </div>

                    {/* TABLE */}

                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">

                        <div className="overflow-x-auto">

                            <table className="min-w-[1450px] w-full">

                                <thead className="bg-gray-50 border-b border-gray-200">

                                    <tr>

                                        {[
                                            'NIK',
                                            'Nama',
                                            'Plant',
                                            'Division',
                                            'Department',
                                            'Section',
                                            'Line',
                                            'Jabatan',
                                            'Status',
                                            'Aksi'
                                        ].map(
                                            (
                                                title
                                            ) => (
                                                <th
                                                    key={
                                                        title
                                                    }
                                                    className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider"
                                                >
                                                    {
                                                        title
                                                    }
                                                </th>
                                            )
                                        )}

                                    </tr>
                                </thead>

                                <tbody className="divide-y divide-gray-100">

                                    {loading ? (
                                        <tr>
                                            <td
                                                colSpan="10"
                                                className="px-4 py-10 text-center text-gray-500"
                                            >
                                                Loading data...
                                            </td>
                                        </tr>
                                    ) : currentRows.length ===
                                      0 ? (
                                        <tr>
                                            <td
                                                colSpan="10"
                                                className="px-4 py-10 text-center text-gray-500"
                                            >
                                                Tidak ada data karyawan
                                            </td>
                                        </tr>
                                    ) : (
                                        currentRows.map(
                                            (
                                                item
                                            ) => (
                                                <tr
                                                    key={
                                                        item.id
                                                    }
                                                    className="hover:bg-gray-50"
                                                >

                                                    <td className="px-4 py-3 text-sm text-gray-700">
                                                        {
                                                            item.national_id ||
                                                            '-'
                                                        }
                                                    </td>

                                                    <td className="px-4 py-3 text-sm font-medium text-gray-900">
                                                        {
                                                            item.name ||
                                                            '-'
                                                        }
                                                    </td>

                                                    <td className="px-4 py-3 text-sm text-gray-700">
                                                        {
                                                            item.plant ||
                                                            '-'
                                                        }
                                                    </td>

                                                    <td className="px-4 py-3 text-sm text-gray-700">
                                                        {
                                                            item.division ||
                                                            '-'
                                                        }
                                                    </td>

                                                    <td className="px-4 py-3 text-sm text-gray-700">
                                                        {
                                                            item.department ||
                                                            '-'
                                                        }
                                                    </td>

                                                    <td className="px-4 py-3 text-sm text-gray-700">
                                                        {
                                                            item.section ||
                                                            '-'
                                                        }
                                                    </td>

                                                    <td className="px-4 py-3 text-sm text-gray-700">
                                                        {
                                                            item.line ||
                                                            '-'
                                                        }
                                                    </td>

                                                    <td className="px-4 py-3 text-sm text-gray-700">
                                                        {
                                                            item.position ||
                                                            '-'
                                                        }
                                                    </td>

                                                    <td className="px-4 py-3">
                                                        <span
                                                            className={`inline-flex px-2.5 py-1 rounded-full text-xs font-medium ${getStatusClass(
                                                                item.employment_status
                                                            )}`}
                                                        >
                                                            {
                                                                item.employment_status ||
                                                                '-'
                                                            }
                                                        </span>
                                                    </td>

                                                    <td className="px-4 py-3">

                                                        <div className="flex flex-wrap gap-2">

                                                            <button
                                                                type="button"
                                                                onClick={() =>
                                                                    handleDetail(
                                                                        item
                                                                    )
                                                                }
                                                                className="px-3 py-1.5 text-xs bg-cyan-500 text-white rounded-md hover:bg-cyan-600"
                                                            >
                                                                Detail
                                                            </button>

                                                            <button
                                                                type="button"
                                                                onClick={() =>
                                                                    handleEdit(
                                                                        item
                                                                    )
                                                                }
                                                                className="px-3 py-1.5 text-xs bg-yellow-500 text-white rounded-md hover:bg-yellow-600"
                                                            >
                                                                Edit
                                                            </button>

                                                            <button
                                                                type="button"
                                                                onClick={() =>
                                                                    handleDelete(
                                                                        item.id
                                                                    )
                                                                }
                                                                className="px-3 py-1.5 text-xs bg-red-500 text-white rounded-md hover:bg-red-600"
                                                            >
                                                                Hapus
                                                            </button>

                                                        </div>
                                                    </td>

                                                </tr>
                                            )
                                        )
                                    )}

                                </tbody>

                            </table>
                        </div>
                    </div>

                    {/* PAGINATION */}

                    <div className="mt-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">

                        <div className="flex items-center gap-2">
                            <span className="text-sm text-gray-600">
                                Tampilkan
                            </span>

                            <select
                                value={
                                    rowsPerPage
                                }
                                onChange={(
                                    event
                                ) => {
                                    setRowsPerPage(
                                        Number(
                                            event
                                                .target
                                                .value
                                        )
                                    );

                                    setCurrentPage(
                                        1
                                    );
                                }}
                                className="border border-gray-300 rounded-md px-3 py-2 text-sm bg-white"
                            >
                                <option value="10">
                                    10
                                </option>

                                <option value="25">
                                    25
                                </option>

                                <option value="50">
                                    50
                                </option>

                                <option value="100">
                                    100
                                </option>
                            </select>

                            <span className="text-sm text-gray-600">
                                data
                            </span>
                        </div>

                        <div className="flex items-center gap-3">

                            <button
                                type="button"
                                onClick={() =>
                                    setCurrentPage(
                                        (prev) =>
                                            Math.max(
                                                prev -
                                                    1,
                                                1
                                            )
                                    )
                                }
                                disabled={
                                    currentPage ===
                                    1
                                }
                                className="px-3 py-2 text-sm rounded-md bg-cyan-500 text-white hover:bg-cyan-600 disabled:bg-gray-100 disabled:text-gray-400"
                            >
                                Prev
                            </button>

                            <span className="text-sm text-gray-600">
                                Halaman{' '}
                                {filteredKaryawan.length >
                                0
                                    ? currentPage
                                    : 0}{' '}
                                dari{' '}
                                {
                                    safeTotalPages
                                }
                            </span>

                            <button
                                type="button"
                                onClick={() =>
                                    setCurrentPage(
                                        (
                                            prev
                                        ) =>
                                            Math.min(
                                                prev +
                                                    1,
                                                totalPages ||
                                                    1
                                            )
                                    )
                                }
                                disabled={
                                    currentPage >=
                                        totalPages ||
                                    totalPages ===
                                        0
                                }
                                className="px-3 py-2 text-sm rounded-md bg-cyan-500 text-white hover:bg-cyan-600 disabled:bg-gray-100 disabled:text-gray-400"
                            >
                                Next
                            </button>

                        </div>

                    </div>

                </div>
            ) : (

                /* =================================================
                   FORM
                ================================================= */

                <div className="bg-white rounded-xl border border-gray-200 shadow-sm">

                    <div className="p-4 md:p-6 border-b border-gray-200">

                        <h2 className="text-xl font-bold text-gray-900">
                            {editingId
                                ? 'Edit Karyawan'
                                : 'Tambah Karyawan'}
                        </h2>

                        <p className="text-sm text-gray-500 mt-1">
                            Lengkapi data karyawan sesuai
                            struktur organisasi OTICS Indonesia.
                        </p>

                    </div>

                    <form
                        onSubmit={
                            handleSubmit
                        }
                        className="p-4 md:p-6 space-y-6"
                    >

                        {/* =================================================
                            FOTO
                        ================================================= */}

                        <FormSection
                            title="Foto"
                        >
                            <InputField
                                label="Foto (URL / Path)"
                                name="photo"
                                value={
                                    formData.photo
                                }
                                onChange={
                                    handleChange
                                }
                            />
                        </FormSection>

                        {/* =================================================
                            DATA PRIBADI
                        ================================================= */}

                        <FormSection
                            title="Data Pribadi"
                        >

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

                                <InputField
                                    label="NIK"
                                    name="national_id"
                                    value={
                                        formData.national_id
                                    }
                                    onChange={
                                        handleChange
                                    }
                                    required
                                />

                                <InputField
                                    label="Nama"
                                    name="name"
                                    value={
                                        formData.name
                                    }
                                    onChange={
                                        handleChange
                                    }
                                    required
                                />

                                <InputField
                                    label="Tempat Lahir"
                                    name="place_of_birth"
                                    value={
                                        formData.place_of_birth
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                                <InputField
                                    label="Tanggal Lahir"
                                    name="date_of_birth"
                                    type="date"
                                    value={normalizeDate(
                                        formData.date_of_birth
                                    )}
                                    onChange={
                                        handleChange
                                    }
                                />

                                <SelectField
                                    label="Jenis Kelamin"
                                    name="gender"
                                    value={
                                        formData.gender
                                    }
                                    onChange={
                                        handleChange
                                    }
                                    options={[
                                        {
                                            value: 'Laki-laki',
                                            label: 'Laki-laki'
                                        },
                                        {
                                            value: 'Perempuan',
                                            label: 'Perempuan'
                                        }
                                    ]}
                                />

                                <SelectField
                                    label="Golongan Darah"
                                    name="blood_type"
                                    value={
                                        formData.blood_type
                                    }
                                    onChange={
                                        handleChange
                                    }
                                    options={[
                                        {
                                            value: '',
                                            label: 'Pilih Golongan Darah'
                                        },
                                        {
                                            value: 'A',
                                            label: 'A'
                                        },
                                        {
                                            value: 'B',
                                            label: 'B'
                                        },
                                        {
                                            value: 'AB',
                                            label: 'AB'
                                        },
                                        {
                                            value: 'O',
                                            label: 'O'
                                        }
                                    ]}
                                />

                                <SelectField
                                    label="Agama"
                                    name="religion"
                                    value={
                                        formData.religion
                                    }
                                    onChange={
                                        handleChange
                                    }
                                    options={[
                                        {
                                            value: '',
                                            label: 'Pilih Agama'
                                        },
                                        {
                                            value: 'Islam',
                                            label: 'Islam'
                                        },
                                        {
                                            value: 'Kristen Protestan',
                                            label: 'Kristen Protestan'
                                        },
                                        {
                                            value: 'Kristen Katolik',
                                            label: 'Kristen Katolik'
                                        },
                                        {
                                            value: 'Hindu',
                                            label: 'Hindu'
                                        },
                                        {
                                            value: 'Buddha',
                                            label: 'Buddha'
                                        },
                                        {
                                            value: 'Konghucu',
                                            label: 'Konghucu'
                                        }
                                    ]}
                                />

                                <SelectField
                                    label="Status Perkawinan"
                                    name="marital_status"
                                    value={
                                        formData.marital_status
                                    }
                                    onChange={
                                        handleChange
                                    }
                                    options={[
                                        {
                                            value: 'Belum Kawin',
                                            label: 'Belum Kawin'
                                        },
                                        {
                                            value: 'Kawin',
                                            label: 'Kawin'
                                        },
                                        {
                                            value: 'Cerai Hidup',
                                            label: 'Cerai Hidup'
                                        },
                                        {
                                            value: 'Cerai Mati',
                                            label: 'Cerai Mati'
                                        }
                                    ]}
                                />

                                <InputField
                                    label="Jumlah Anak"
                                    name="number_of_children"
                                    type="number"
                                    min="0"
                                    value={
                                        formData.number_of_children
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                            </div>
                        </FormSection>

                        {/* =================================================
                            KONTAK
                        ================================================= */}

                        <FormSection
                            title="Kontak & Alamat"
                        >

                            <div className="grid grid-cols-1 gap-4">

                                <TextAreaField
                                    label="Alamat KTP"
                                    name="ktp_address"
                                    value={
                                        formData.ktp_address
                                    }
                                    onChange={
                                        handleChange
                                    }
                                    rows={3}
                                />

                                <TextAreaField
                                    label="Alamat Domisili"
                                    name="residential_address"
                                    value={
                                        formData.residential_address
                                    }
                                    onChange={
                                        handleChange
                                    }
                                    rows={3}
                                />

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

                                    <InputField
                                        label="No. Telepon"
                                        name="phone_number"
                                        value={
                                            formData.phone_number
                                        }
                                        onChange={
                                            handleChange
                                        }
                                    />

                                    <InputField
                                        label="Email"
                                        name="email"
                                        type="email"
                                        value={
                                            formData.email
                                        }
                                        onChange={
                                            handleChange
                                        }
                                    />

                                    <InputField
                                        label="Kontak Darurat"
                                        name="emergency_contact"
                                        value={
                                            formData.emergency_contact
                                        }
                                        onChange={
                                            handleChange
                                        }
                                    />

                                </div>
                            </div>

                        </FormSection>

                        {/* =================================================
                            PENDIDIKAN
                        ================================================= */}

                        <FormSection
                            title="Pendidikan"
                        >

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

                                <SelectField
                                    label="Pendidikan Terakhir"
                                    name="last_education"
                                    value={
                                        formData.last_education
                                    }
                                    onChange={
                                        handleChange
                                    }
                                    options={[
                                        {
                                            value: '',
                                            label: 'Pilih Pendidikan'
                                        },
                                        {
                                            value: 'SD',
                                            label: 'SD'
                                        },
                                        {
                                            value: 'SMP',
                                            label: 'SMP'
                                        },
                                        {
                                            value: 'SMA',
                                            label: 'SMA'
                                        },
                                        {
                                            value: 'D1',
                                            label: 'D1'
                                        },
                                        {
                                            value: 'D2',
                                            label: 'D2'
                                        },
                                        {
                                            value: 'D3',
                                            label: 'D3'
                                        },
                                        {
                                            value: 'D4',
                                            label: 'D4'
                                        },
                                        {
                                            value: 'S1',
                                            label: 'S1'
                                        },
                                        {
                                            value: 'S2',
                                            label: 'S2'
                                        },
                                        {
                                            value: 'S3',
                                            label: 'S3'
                                        }
                                    ]}
                                />

                                <InputField
                                    label="Institusi Pendidikan"
                                    name="educational_institution"
                                    value={
                                        formData.educational_institution
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                                <InputField
                                    label="Tahun Lulus"
                                    name="graduation_year"
                                    type="number"
                                    min="1900"
                                    max="2099"
                                    value={
                                        formData.graduation_year
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                                <InputField
                                    label="Jurusan"
                                    name="major"
                                    value={
                                        formData.major
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                            </div>

                        </FormSection>

                        {/* =================================================
                            ORGANISASI
                        ================================================= */}

                        <FormSection
                            title="Data Pekerjaan & Organisasi"
                        >

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

                                <InputField
                                    label="NIP"
                                    name="employee_number"
                                    value={
                                        formData.employee_number
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                                <InputField
                                    label="Plant"
                                    name="plant"
                                    value={
                                        formData.plant
                                    }
                                    onChange={
                                        handleChange
                                    }
                                    placeholder="Contoh: EJIP"
                                />

                                {/* DIVISION */}

                                <SearchableSelect
                                    label="Division"
                                    name="division"
                                    placeholder="Pilih Division"
                                    options={
                                        divisionOptions
                                    }
                                    value={
                                        formData.division
                                    }
                                    onChange={
                                        handleOrganizationChange
                                    }
                                />

                                {/* SUB DIVISION */}

                                <SearchableSelect
                                    label="Sub Division"
                                    name="sub_division"
                                    placeholder="Pilih Sub Division"
                                    options={
                                        subDivisionOptions
                                    }
                                    value={
                                        formData.sub_division
                                    }
                                    onChange={
                                        handleOrganizationChange
                                    }
                                    disabled={isOrganizationDisabled(
                                        'sub_division',
                                        formData
                                    )}
                                />

                                {/* DEPARTMENT */}

                                <SearchableSelect
                                    label="Department"
                                    name="department"
                                    placeholder="Pilih Department"
                                    options={
                                        departmentOptions
                                    }
                                    value={
                                        formData.department
                                    }
                                    onChange={
                                        handleOrganizationChange
                                    }
                                    disabled={isOrganizationDisabled(
                                        'department',
                                        formData
                                    )}
                                />

                                {/* SUB DEPARTMENT */}

                                <SearchableSelect
                                    label="Sub Department"
                                    name="sub_department"
                                    placeholder="Pilih Sub Department"
                                    options={
                                        subDepartmentOptions
                                    }
                                    value={
                                        formData.sub_department
                                    }
                                    onChange={
                                        handleOrganizationChange
                                    }
                                    disabled={isOrganizationDisabled(
                                        'sub_department',
                                        formData
                                    )}
                                />

                                {/* SECTION */}

                                <SearchableSelect
                                    label="Section"
                                    name="section"
                                    placeholder="Pilih Section"
                                    options={
                                        sectionOptions
                                    }
                                    value={
                                        formData.section
                                    }
                                    onChange={
                                        handleOrganizationChange
                                    }
                                    disabled={isOrganizationDisabled(
                                        'section',
                                        formData
                                    )}
                                />

                                {/* SUB SECTION */}

                                <SearchableSelect
                                    label="Sub Section"
                                    name="sub_section"
                                    placeholder="Pilih Sub Section"
                                    options={
                                        subSectionOptions
                                    }
                                    value={
                                        formData.sub_section
                                    }
                                    onChange={
                                        handleOrganizationChange
                                    }
                                    disabled={isOrganizationDisabled(
                                        'sub_section',
                                        formData
                                    )}
                                />

                                {/* LINE */}

                                <SearchableSelect
                                    label="Line"
                                    name="line"
                                    placeholder="Pilih Line"
                                    options={
                                        lineOptions
                                    }
                                    value={
                                        formData.line
                                    }
                                    onChange={
                                        handleOrganizationChange
                                    }
                                    disabled={isOrganizationDisabled(
                                        'line',
                                        formData
                                    )}
                                />

                                {/* SUB LINE */}

                                <SearchableSelect
                                    label="Sub Line"
                                    name="sub_line"
                                    placeholder="Pilih Sub Line"
                                    options={
                                        subLineOptions
                                    }
                                    value={
                                        formData.sub_line
                                    }
                                    onChange={
                                        handleOrganizationChange
                                    }
                                    disabled={isOrganizationDisabled(
                                        'sub_line',
                                        formData
                                    )}
                                />

                                <InputField
                                    label="Line Status"
                                    name="line_status"
                                    value={
                                        formData.line_status
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                                <InputField
                                    label="Jabatan"
                                    name="position"
                                    value={
                                        formData.position
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                                <InputField
                                    label="Tanggal Masuk"
                                    name="join_date"
                                    type="date"
                                    value={normalizeDate(
                                        formData.join_date
                                    )}
                                    onChange={
                                        handleChange
                                    }
                                />

                                <SelectField
                                    label="Status Karyawan"
                                    name="employment_status"
                                    value={
                                        formData.employment_status
                                    }
                                    onChange={
                                        handleChange
                                    }
                                    options={[
                                        {
                                            value: 'Tetap',
                                            label: 'Tetap'
                                        },
                                        {
                                            value: 'Kontrak',
                                            label: 'Kontrak'
                                        },
                                        {
                                            value: 'Magang',
                                            label: 'Magang'
                                        },
                                        {
                                            value: 'Resign',
                                            label: 'Resign'
                                        }
                                    ]}
                                />

                            </div>

                        </FormSection>

                        {/* =================================================
                            KEUANGAN
                        ================================================= */}

                        <FormSection
                            title="Keuangan"
                        >

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

                                <InputField
                                    label="Gaji Pokok"
                                    name="basic_salary"
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    value={
                                        formData.basic_salary
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                                <InputField
                                    label="Tunjangan"
                                    name="allowance"
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    value={
                                        formData.allowance
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                                <InputField
                                    label="No. Rekening"
                                    name="bank_account_number"
                                    value={
                                        formData.bank_account_number
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                                <InputField
                                    label="Bank"
                                    name="bank_name"
                                    value={
                                        formData.bank_name
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                                <InputField
                                    label="BPJS Kesehatan"
                                    name="health_insurance_number"
                                    value={
                                        formData.health_insurance_number
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                                <InputField
                                    label="BPJS Ketenagakerjaan"
                                    name="employment_insurance_number"
                                    value={
                                        formData.employment_insurance_number
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                            </div>

                        </FormSection>

                        {/* =================================================
                            CATATAN
                        ================================================= */}

                        <FormSection
                            title="Catatan"
                        >

                            <div className="grid grid-cols-1 gap-4">

                                <TextAreaField
                                    label="Riwayat Sakit"
                                    name="medical_history"
                                    value={
                                        formData.medical_history
                                    }
                                    onChange={
                                        handleChange
                                    }
                                    rows={4}
                                />

                                <TextAreaField
                                    label="Catatan Lain"
                                    name="other_notes"
                                    value={
                                        formData.other_notes
                                    }
                                    onChange={
                                        handleChange
                                    }
                                    rows={4}
                                />

                            </div>

                        </FormSection>

                        {/* =================================================
                            BUTTON
                        ================================================= */}

                        <div className="flex flex-col sm:flex-row gap-3 pt-2">

                            <Buttonv1
                                type="submit"
                                variant="primary"
                                size="lg"
                                disabled={saving}
                                className="w-full sm:w-auto"
                            >
                                {saving
                                    ? 'Menyimpan...'
                                    : editingId
                                    ? 'Update Karyawan'
                                    : 'Simpan Karyawan'}
                            </Buttonv1>

                            <Buttonv1
                                type="button"
                                variant="outline"
                                size="lg"
                                disabled={saving}
                                onClick={() => {
                                    resetForm();
                                    setActiveTab(
                                        'list'
                                    );
                                }}
                                className="w-full sm:w-auto"
                            >
                                Batal
                            </Buttonv1>

                        </div>

                    </form>
                </div>
            )}

            {/* =================================================
                DETAIL MODAL
            ================================================= */}

            {showDetailModal &&
                selectedKaryawan && (
                    <div className="fixed inset-0 z-[200] bg-black/50 p-3 sm:p-4 flex items-center justify-center">

                        <div className="bg-white rounded-xl shadow-2xl w-full max-w-5xl max-h-[92vh] overflow-y-auto">

                            {/* HEADER */}

                            <div className="sticky top-0 z-10 bg-white border-b px-4 sm:px-6 py-4 flex items-center justify-between">

                                <div>
                                    <h3 className="font-bold text-lg text-gray-900">
                                        Detail Karyawan
                                    </h3>

                                    <p className="text-xs text-gray-500 mt-1">
                                        ID: {
                                            selectedKaryawan.id
                                        }
                                    </p>
                                </div>

                                <button
                                    type="button"
                                    onClick={
                                        closeDetailModal
                                    }
                                    className="w-10 h-10 rounded-lg hover:bg-gray-100 text-gray-500 text-xl"
                                >
                                    ✕
                                </button>

                            </div>

                            {/* CONTENT */}

                            <div className="p-4 sm:p-6 space-y-5">

                                {/* FOTO */}

                                {selectedKaryawan.photo && (
                                    <div className="flex justify-center">
                                        <img
                                            src={
                                                selectedKaryawan.photo
                                            }
                                            alt="Foto Karyawan"
                                            className="w-28 h-28 sm:w-32 sm:h-32 object-cover rounded-full border-4 border-cyan-100 shadow"
                                        />
                                    </div>
                                )}

                                <DetailSection title="Data Pribadi">

                                    <DetailItem
                                        label="NIK"
                                        value={
                                            selectedKaryawan.national_id
                                        }
                                    />

                                    <DetailItem
                                        label="Nama"
                                        value={
                                            selectedKaryawan.name
                                        }
                                    />

                                    <DetailItem
                                        label="Tempat Lahir"
                                        value={
                                            selectedKaryawan.place_of_birth
                                        }
                                    />

                                    <DetailItem
                                        label="Tanggal Lahir"
                                        value={normalizeDate(
                                            selectedKaryawan.date_of_birth
                                        )}
                                    />

                                    <DetailItem
                                        label="Jenis Kelamin"
                                        value={
                                            selectedKaryawan.gender
                                        }
                                    />

                                    <DetailItem
                                        label="Golongan Darah"
                                        value={
                                            selectedKaryawan.blood_type
                                        }
                                    />

                                    <DetailItem
                                        label="Agama"
                                        value={
                                            selectedKaryawan.religion
                                        }
                                    />

                                    <DetailItem
                                        label="Status Perkawinan"
                                        value={
                                            selectedKaryawan.marital_status
                                        }
                                    />

                                    <DetailItem
                                        label="Jumlah Anak"
                                        value={
                                            selectedKaryawan.number_of_children
                                        }
                                    />

                                </DetailSection>

                                <DetailSection title="Kontak & Alamat">

                                    <DetailItem
                                        label="Alamat KTP"
                                        value={
                                            selectedKaryawan.ktp_address
                                        }
                                        full
                                    />

                                    <DetailItem
                                        label="Alamat Domisili"
                                        value={
                                            selectedKaryawan.residential_address
                                        }
                                        full
                                    />

                                    <DetailItem
                                        label="No. Telepon"
                                        value={
                                            selectedKaryawan.phone_number
                                        }
                                    />

                                    <DetailItem
                                        label="Email"
                                        value={
                                            selectedKaryawan.email
                                        }
                                    />

                                    <DetailItem
                                        label="Kontak Darurat"
                                        value={
                                            selectedKaryawan.emergency_contact
                                        }
                                    />

                                </DetailSection>

                                <DetailSection title="Pendidikan">

                                    <DetailItem
                                        label="Pendidikan Terakhir"
                                        value={
                                            selectedKaryawan.last_education
                                        }
                                    />

                                    <DetailItem
                                        label="Institusi Pendidikan"
                                        value={
                                            selectedKaryawan.educational_institution
                                        }
                                    />

                                    <DetailItem
                                        label="Tahun Lulus"
                                        value={
                                            selectedKaryawan.graduation_year
                                        }
                                    />

                                    <DetailItem
                                        label="Jurusan"
                                        value={
                                            selectedKaryawan.major
                                        }
                                    />

                                </DetailSection>

                                <DetailSection title="Data Pekerjaan & Organisasi">

                                    <DetailItem
                                        label="NIP"
                                        value={
                                            selectedKaryawan.employee_number
                                        }
                                    />

                                    <DetailItem
                                        label="Plant"
                                        value={
                                            selectedKaryawan.plant
                                        }
                                    />

                                    <DetailItem
                                        label="Division"
                                        value={
                                            selectedKaryawan.division
                                        }
                                    />

                                    <DetailItem
                                        label="Sub Division"
                                        value={
                                            selectedKaryawan.sub_division
                                        }
                                    />

                                    <DetailItem
                                        label="Department"
                                        value={
                                            selectedKaryawan.department
                                        }
                                    />

                                    <DetailItem
                                        label="Sub Department"
                                        value={
                                            selectedKaryawan.sub_department
                                        }
                                    />

                                    <DetailItem
                                        label="Section"
                                        value={
                                            selectedKaryawan.section
                                        }
                                    />

                                    <DetailItem
                                        label="Sub Section"
                                        value={
                                            selectedKaryawan.sub_section
                                        }
                                    />

                                    <DetailItem
                                        label="Line"
                                        value={
                                            selectedKaryawan.line
                                        }
                                    />

                                    <DetailItem
                                        label="Sub Line"
                                        value={
                                            selectedKaryawan.sub_line
                                        }
                                    />

                                    <DetailItem
                                        label="Line Status"
                                        value={
                                            selectedKaryawan.line_status
                                        }
                                    />

                                    <DetailItem
                                        label="Jabatan"
                                        value={
                                            selectedKaryawan.position
                                        }
                                    />

                                    <DetailItem
                                        label="Tanggal Masuk"
                                        value={normalizeDate(
                                            selectedKaryawan.join_date
                                        )}
                                    />

                                    <DetailItem
                                        label="Status Karyawan"
                                        value={
                                            selectedKaryawan.employment_status
                                        }
                                    />

                                </DetailSection>

                                <DetailSection title="Keuangan">

                                    <DetailItem
                                        label="Gaji Pokok"
                                        value={
                                            selectedKaryawan.basic_salary
                                        }
                                    />

                                    <DetailItem
                                        label="Tunjangan"
                                        value={
                                            selectedKaryawan.allowance
                                        }
                                    />

                                    <DetailItem
                                        label="No. Rekening"
                                        value={
                                            selectedKaryawan.bank_account_number
                                        }
                                    />

                                    <DetailItem
                                        label="Bank"
                                        value={
                                            selectedKaryawan.bank_name
                                        }
                                    />

                                    <DetailItem
                                        label="BPJS Kesehatan"
                                        value={
                                            selectedKaryawan.health_insurance_number
                                        }
                                    />

                                    <DetailItem
                                        label="BPJS Ketenagakerjaan"
                                        value={
                                            selectedKaryawan.employment_insurance_number
                                        }
                                    />

                                </DetailSection>

                                <DetailSection title="Catatan">

                                    <DetailItem
                                        label="Riwayat Sakit"
                                        value={
                                            selectedKaryawan.medical_history
                                        }
                                        full
                                    />

                                    <DetailItem
                                        label="Catatan Lain"
                                        value={
                                            selectedKaryawan.other_notes
                                        }
                                        full
                                    />

                                </DetailSection>

                                <DetailSection title="Informasi Sistem">

                                    <DetailItem
                                        label="Created At"
                                        value={
                                            selectedKaryawan.created_at
                                                ? new Date(
                                                      selectedKaryawan.created_at
                                                  ).toLocaleString(
                                                      'id-ID'
                                                  )
                                                : '-'
                                        }
                                    />

                                    <DetailItem
                                        label="Updated At"
                                        value={
                                            selectedKaryawan.updated_at
                                                ? new Date(
                                                      selectedKaryawan.updated_at
                                                  ).toLocaleString(
                                                      'id-ID'
                                                  )
                                                : '-'
                                        }
                                    />

                                </DetailSection>

                            </div>

                            {/* FOOTER */}

                            <div className="sticky bottom-0 bg-white border-t px-4 sm:px-6 py-3 flex justify-end">

                                <Buttonv1
                                    type="button"
                                    variant="outline"
                                    onClick={
                                        closeDetailModal
                                    }
                                >
                                    Tutup
                                </Buttonv1>

                            </div>

                        </div>
                    </div>
                )}

        </div>
    );
};

/*
|--------------------------------------------------------------------------
| FORM SECTION
|--------------------------------------------------------------------------
*/

const FormSection = ({
    title,
    children
}) => {
    return (
        <section className="border border-gray-200 rounded-xl overflow-visible">

            <div className="bg-cyan-50 border-b border-cyan-100 px-4 py-3">
                <h3 className="font-semibold text-cyan-700">
                    {title}
                </h3>
            </div>

            <div className="p-4">
                {children}
            </div>

        </section>
    );
};

/*
|--------------------------------------------------------------------------
| FILTER INPUT
|--------------------------------------------------------------------------
*/

const FilterInput = ({
    name,
    placeholder,
    value,
    onChange
}) => {
    const [
        localValue,
        setLocalValue
    ] = useState(
        value || ''
    );

    useEffect(() => {
        setLocalValue(
            value || ''
        );
    }, [value]);

    useEffect(() => {
        const timeout =
            setTimeout(() => {
                if (
                    localValue !==
                    value
                ) {
                    onChange({
                        target: {
                            name,
                            value: localValue
                        }
                    });
                }
            }, 300);

        return () =>
            clearTimeout(timeout);
    }, [
        localValue,
        value,
        name,
        onChange
    ]);

    return (
        <input
            type="text"
            value={localValue}
            onChange={(event) =>
                setLocalValue(
                    event.target.value
                )
            }
            placeholder={
                placeholder
            }
            className="border border-gray-300 rounded-md p-3 w-full bg-white focus:outline-none focus:ring-2 focus:ring-cyan-300 focus:border-cyan-400"
        />
    );
};

/*
|--------------------------------------------------------------------------
| DETAIL ITEM
|--------------------------------------------------------------------------
*/

const DetailItem = ({
    label,
    value,
    full = false
}) => {
    return (
        <div
            className={
                full
                    ? 'md:col-span-2'
                    : ''
            }
        >
            <dt className="text-xs font-medium text-gray-500 uppercase tracking-wide">
                {label}
            </dt>

            <dd className="mt-1 text-sm text-gray-900 whitespace-pre-wrap break-words">
                {value !==
                    null &&
                value !==
                    undefined &&
                value !== ''
                    ? value
                    : '-'}
            </dd>
        </div>
    );
};

/*
|--------------------------------------------------------------------------
| DETAIL SECTION
|--------------------------------------------------------------------------
*/

const DetailSection = ({
    title,
    children
}) => {
    return (
        <section className="border border-gray-200 rounded-xl overflow-hidden">

            <div className="bg-cyan-50 border-b border-cyan-100 px-4 py-3">
                <h4 className="font-semibold text-cyan-700">
                    {title}
                </h4>
            </div>

            <dl className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5 p-4">
                {children}
            </dl>

        </section>
    );
};

export default Karyawan;